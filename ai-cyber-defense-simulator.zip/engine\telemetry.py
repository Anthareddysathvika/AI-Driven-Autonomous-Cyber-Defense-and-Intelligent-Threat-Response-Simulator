"""
Telemetry and State Management Module
Maintains sliding-window traffic statistics per IP, in-memory event log buffer,
active user sessions, and real-time operational metrics for SOC visualization.
"""

import time
from collections import deque
from threading import Lock

class TelemetryManager:
    def __init__(self, max_events=600):
        self.lock = Lock()
        self.max_events = max_events
        self.events = deque(maxlen=max_events)
        
        # Per-IP sliding window trackers: ip -> deque of timestamps
        self.ip_request_history = {}
        self.ip_failed_logins = {}
        self.ip_endpoints = {}

        # Active User Sessions: session_id -> dict
        self.sessions = {
            "sess_demo_analyst": {
                "session_id": "sess_demo_analyst",
                "user": "sec_analyst_01",
                "ip": "192.168.1.15",
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "status": "ACTIVE",
                "role": "Security Operations Analyst"
            },
            "sess_demo_admin": {
                "session_id": "sess_demo_admin",
                "user": "sys_admin",
                "ip": "192.168.1.20",
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "status": "ACTIVE",
                "role": "Cloud Infrastructure Admin"
            }
        }

        # Telemetry counters
        self.total_ingested = 0
        self.threats_neutralized = 0
        self.sessions_terminated = 0
        self.ip_blocks_enacted = 0
        self.category_counts = {
            "BENIGN": 0,
            "BRUTE_FORCE": 0,
            "SQL_INJECTION": 0,
            "XSS": 0,
            "PATH_TRAVERSAL": 0,
            "DDOS_FLOOD": 0,
            "RECON_SCAN": 0
        }
        self.action_counts = {
            "ALLOW": 0,
            "BLOCK_IP": 0,
            "TERMINATE_SESSION": 0,
            "SECURITY_ALERT": 0,
            "RATE_LIMIT": 0,
            "DROPPED": 0
        }

        # Chart time buckets (last 20 intervals, each 5 seconds)
        self.traffic_timeline = deque(maxlen=25)
        self._init_timeline()

    def _init_timeline(self):
        curr = int(time.time())
        for i in range(25):
            t_str = time.strftime("%H:%M:%S", time.localtime(curr - (24 - i) * 5))
            self.traffic_timeline.append({
                "time": t_str,
                "total": 0,
                "threats": 0
            })

    def track_request(self, ip: str, endpoint: str, is_failed_login: bool = False):
        """Records a request in the sliding window for rate/behavior calculations."""
        with self.lock:
            now = time.time()

            if ip not in self.ip_request_history:
                self.ip_request_history[ip] = deque()
            self.ip_request_history[ip].append(now)

            if ip not in self.ip_endpoints:
                self.ip_endpoints[ip] = deque()
            self.ip_endpoints[ip].append((now, endpoint))

            if is_failed_login:
                if ip not in self.ip_failed_logins:
                    self.ip_failed_logins[ip] = deque()
                self.ip_failed_logins[ip].append(now)

            # Prune older than 60s
            cutoff_60 = now - 60
            while self.ip_request_history[ip] and self.ip_request_history[ip][0] < cutoff_60:
                self.ip_request_history[ip].popleft()

            while self.ip_endpoints[ip] and self.ip_endpoints[ip][0][0] < cutoff_60:
                self.ip_endpoints[ip].popleft()

            if ip in self.ip_failed_logins:
                while self.ip_failed_logins[ip] and self.ip_failed_logins[ip][0] < cutoff_60:
                    self.ip_failed_logins[ip].popleft()

    def get_historical_context(self, ip: str) -> dict:
        """Computes instantaneous sliding-window metrics for an IP."""
        with self.lock:
            now = time.time()
            cutoff_10 = now - 10
            cutoff_30 = now - 30

            # Requests in last 10s
            reqs_10s = sum(1 for t in self.ip_request_history.get(ip, []) if t >= cutoff_10)
            rate_10s = round(reqs_10s / 10.0, 2)

            # Failed logins in last 30s
            failed_30s = sum(1 for t in self.ip_failed_logins.get(ip, []) if t >= cutoff_30)

            # Unique endpoints probed in last 10s
            eps_10s = {ep for (t, ep) in self.ip_endpoints.get(ip, []) if t >= cutoff_10}
            unique_eps = max(1, len(eps_10s))

            return {
                "req_rate_10s": rate_10s,
                "failed_logins_30s": failed_30s,
                "unique_endpoints_10s": unique_eps
            }

    def record_event(self, event_record: dict):
        """Appends an analyzed event and updates telemetry statistics."""
        with self.lock:
            self.events.appendleft(event_record)
            self.total_ingested += 1

            cat = event_record.get("classification", "BENIGN")
            if cat in self.category_counts:
                self.category_counts[cat] += 1
            else:
                self.category_counts[cat] = 1

            actions = event_record.get("actions_taken", [])
            is_threat = (cat != "BENIGN") or (event_record.get("risk_score", 0) >= 60)

            if is_threat:
                self.threats_neutralized += 1

            for act in actions:
                act_code = act.get("action", "")
                if act_code in self.action_counts:
                    self.action_counts[act_code] += 1
                if act_code == "BLOCK_IP":
                    self.ip_blocks_enacted += 1
                elif act_code == "TERMINATE_SESSION":
                    self.sessions_terminated += 1

            # Update timeline bucket
            t_str = time.strftime("%H:%M:%S")
            if self.traffic_timeline and self.traffic_timeline[-1]["time"] == t_str:
                self.traffic_timeline[-1]["total"] += 1
                if is_threat:
                    self.traffic_timeline[-1]["threats"] += 1
            else:
                self.traffic_timeline.append({
                    "time": t_str,
                    "total": 1,
                    "threats": 1 if is_threat else 0
                })

    def get_events(self, limit=100, filter_type=None, filter_risk=None):
        """Retrieves filtered list of recent events."""
        with self.lock:
            res = list(self.events)
            if filter_type and filter_type != "ALL":
                res = [e for e in res if e.get("classification") == filter_type]
            if filter_risk and filter_risk != "ALL":
                res = [e for e in res if e.get("risk_level") == filter_risk]
            return res[:limit]

    def register_or_update_session(self, session_id: str, user: str, ip: str) -> dict:
        """Registers a new session or updates last-seen for an existing one."""
        with self.lock:
            if session_id not in self.sessions:
                self.sessions[session_id] = {
                    "session_id": session_id,
                    "user": user,
                    "ip": ip,
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "status": "ACTIVE",
                    "role": "Authenticated User"
                }
            return self.sessions[session_id]

    def terminate_session(self, session_id: str, reason: str = "Autonomous Security Containment") -> bool:
        """Marks a session as TERMINATED/REVOKED."""
        with self.lock:
            if session_id in self.sessions:
                self.sessions[session_id]["status"] = "TERMINATED"
                self.sessions[session_id]["revoked_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
                self.sessions[session_id]["revoke_reason"] = reason
                return True
            return False

    def get_sessions(self) -> list:
        """Returns all sessions."""
        with self.lock:
            return list(self.sessions.values())

    def get_metrics(self) -> dict:
        """Compiles real-time metrics summary for the dashboard."""
        with self.lock:
            # Calculate active threat level (DEFCON / Threat Matrix)
            recent_threats = sum(
                1 for e in list(self.events)[:30]
                if e.get("risk_level") in ["HIGH", "CRITICAL"]
            )
            if recent_threats >= 8:
                defcon = "CRITICAL (DEFCON 1)"
                defcon_color = "#ff2a5f"
            elif recent_threats >= 4:
                defcon = "ELEVATED (DEFCON 2)"
                defcon_color = "#ffaa00"
            elif recent_threats >= 1:
                defcon = "GUARDED (DEFCON 3)"
                defcon_color = "#00d2ff"
            else:
                defcon = "NORMAL (DEFCON 5)"
                defcon_color = "#00ff88"

            active_sess_count = sum(1 for s in self.sessions.values() if s.get("status") == "ACTIVE")
            revoked_sess_count = sum(1 for s in self.sessions.values() if s.get("status") == "TERMINATED")

            return {
                "total_ingested": self.total_ingested,
                "threats_neutralized": self.threats_neutralized,
                "ip_blocks_enacted": self.ip_blocks_enacted,
                "sessions_active": active_sess_count,
                "sessions_terminated": revoked_sess_count,
                "category_counts": dict(self.category_counts),
                "action_counts": dict(self.action_counts),
                "timeline": list(self.traffic_timeline),
                "defcon": defcon,
                "defcon_color": defcon_color,
                "mean_response_time_ms": 2.8  # Autonomous algorithmic response latency
            }

    def reset(self):
        """Clears buffers and counters for fresh demonstration."""
        with self.lock:
            self.events.clear()
            self.total_ingested = 0
            self.threats_neutralized = 0
            self.sessions_terminated = 0
            self.ip_blocks_enacted = 0
            for k in self.category_counts:
                self.category_counts[k] = 0
            for k in self.action_counts:
                self.action_counts[k] = 0
            self.ip_request_history.clear()
            self.ip_failed_logins.clear()
            self.ip_endpoints.clear()
            self.traffic_timeline.clear()
            self._init_timeline()
            for s in self.sessions.values():
                s["status"] = "ACTIVE"
