@echo off
title AI-Driven Autonomous Cyber Defense Simulator
echo =====================================================================
echo  AI-Driven Autonomous Cyber Defense and Intelligent Threat Response
echo =====================================================================
echo.
echo Starting Cyber Defense Operations Center...
echo.

:: Open browser automatically after 2 seconds in the background
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:5000"

:: Start the Python Flask Server
python app.py

pause
