"""
Performance evaluation of the detection and response engine.

Every attack scenario is repeated RUNS times on a fresh system state and benign
traffic is repeated BENIGN_RUNS times. The script reports:
  Detected  - runs in which the expected attack class was identified
  Contained - runs in which a block or rate-limit action was enforced
  First detected at event - position of the first correctly classified event
  False positives - benign events wrongly classified as an attack
Results are printed as a table and saved to evaluation_results.json.
"""

import json
import statistics
import sys

from engine import (AttackSimulator, DefenseOrchestrator, SecurityPipeline,
                    TelemetryManager, ThreatDetectionEngine)

RUNS = 20
BENIGN_RUNS = 300

SCENARIOS = [  # (label, scenario name, expected class)
    ("Brute force", "brute_force", "BRUTE_FORCE"),
    ("SQL injection", "sql_injection", "SQL_INJECTION"),
    ("Cross-site scripting", "xss_attack", "XSS"),
    ("Path traversal", "path_traversal", "PATH_TRAVERSAL"),
    ("DDoS flood", "ddos_flood", "DDOS_FLOOD"),
    ("Reconnaissance scan", "recon_scan", "RECON_SCAN"),
]


def fresh_system(ai):
    telemetry = TelemetryManager(max_events=2000)
    defense = DefenseOrchestrator(telemetry)
    pipeline = SecurityPipeline(ai, telemetry, defense)
    return AttackSimulator(ingestion_pipeline=pipeline.process)


def contained(events):
    for e in events:
        for a in e.get("actions_taken", []):
            if a["action"] in ("BLOCK_IP", "RATE_LIMIT") and a["status"] == "ENFORCED":
                return True
    return False


def main():
    print("Training models ...")
    ai = ThreatDetectionEngine()
    times, rows = [], []

    for label, name, expected in SCENARIOS:
        detected = held = 0
        first_positions, totals = [], []
        for _ in range(RUNS):
            events = fresh_system(ai).run_scenario(name)
            times += [e["response_time_ms"] for e in events]
            totals.append(len(events))
            pos = next((i + 1 for i, e in enumerate(events) if e["classification"] == expected), None)
            if pos:
                detected += 1
                first_positions.append(pos)
            held += contained(events)
        first = round(statistics.median(first_positions)) if first_positions else None
        rows.append({"scenario": label, "detected": detected, "contained": held, "runs": RUNS,
                     "first_detected_at": first, "events_per_run": totals[0]})
        print(f"{label:<22} detected {detected}/{RUNS}  contained {held}/{RUNS}  "
              f"first at event {first} of {totals[0]}")

    false_pos = 0
    for _ in range(BENIGN_RUNS):
        e = fresh_system(ai).run_scenario("benign", count=1)[0]
        times.append(e["response_time_ms"])
        if e["classification"] != "BENIGN" or e["risk_level"] != "LOW":
            false_pos += 1
    print(f"{'Benign traffic':<22} false positives {false_pos}/{BENIGN_RUNS} "
          f"({100 * false_pos / BENIGN_RUNS:.1f}%)")

    summary = {
        "rows": rows,
        "benign": {"false_positives": false_pos, "runs": BENIGN_RUNS},
        "response_time_ms": {"mean": round(statistics.mean(times), 2),
                             "max": round(max(times), 2), "events": len(times)},
    }
    print(f"Mean response time {summary['response_time_ms']['mean']} ms, "
          f"max {summary['response_time_ms']['max']} ms over {len(times)} events")
    with open("evaluation_results.json", "w") as f:
        json.dump(summary, f, indent=2)
    print("Saved evaluation_results.json")


if __name__ == "__main__":
    sys.exit(main())
