"""
SQLite persistence layer.
Stores users, analysed security events, firewall rules and the audit trail
so that detection decisions survive a restart and can be turned into reports.
"""

import json
import os
import sqlite3
import time
from werkzeug.security import generate_password_hash, check_password_hash

DEFAULT_DB = os.environ.get(
    "CYBERDEFENSE_DB",
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cyberdefense.db"),
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('ADMIN', 'USER')),
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    ts TEXT NOT NULL,
    ip TEXT, endpoint TEXT, method TEXT, payload TEXT,
    classification TEXT, confidence REAL,
    risk_score INTEGER, risk_level TEXT, anomaly_score REAL,
    mitre_id TEXT, response_status TEXT, actions TEXT,
    response_time_ms REAL
);
CREATE TABLE IF NOT EXISTS blocked_ips (
    ip TEXT PRIMARY KEY,
    blocked_at TEXT, reason TEXT, attack_type TEXT,
    risk_score INTEGER, auto_blocked INTEGER, status TEXT
);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    actor TEXT, action TEXT, target TEXT, detail TEXT
);
"""


class Database:
    def __init__(self, path: str = DEFAULT_DB):
        self.path = path
        with self._conn() as c:
            c.executescript(SCHEMA)

    def _conn(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    @staticmethod
    def _now() -> str:
        return time.strftime("%Y-%m-%d %H:%M:%S")

    # ---------------- users ---------------- #
    def create_user(self, username: str, password: str, role: str = "USER") -> bool:
        role = role.upper()
        if role not in ("ADMIN", "USER") or not username or len(password) < 6:
            return False
        try:
            with self._conn() as c:
                c.execute(
                    "INSERT INTO users (username, password_hash, role, created_at) VALUES (?,?,?,?)",
                    (username, generate_password_hash(password), role, self._now()),
                )
            return True
        except sqlite3.IntegrityError:
            return False

    def verify_user(self, username: str, password: str):
        with self._conn() as c:
            row = c.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if row and check_password_hash(row["password_hash"], password):
            return {"username": row["username"], "role": row["role"]}
        return None

    def list_users(self) -> list:
        with self._conn() as c:
            rows = c.execute("SELECT username, role, created_at FROM users ORDER BY id").fetchall()
        return [dict(r) for r in rows]

    def seed_default_users(self):
        """Creates the demo accounts on first run."""
        if not self.list_users():
            self.create_user("admin", "Admin@123", "ADMIN")
            self.create_user("analyst", "Analyst@123", "USER")

    # ---------------- events ---------------- #
    def save_event(self, e: dict):
        with self._conn() as c:
            c.execute(
                "INSERT OR REPLACE INTO events VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    e["id"], e.get("full_timestamp"), e.get("ip"), e.get("endpoint"),
                    e.get("method"), str(e.get("payload", ""))[:500],
                    e.get("classification"), e.get("confidence"),
                    e.get("risk_score"), e.get("risk_level"), e.get("anomaly_score"),
                    (e.get("mitre") or {}).get("id"), e.get("response_status"),
                    json.dumps([a.get("action") for a in e.get("actions_taken", [])]),
                    e.get("response_time_ms"),
                ),
            )

    def event_summary(self) -> dict:
        with self._conn() as c:
            total = c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            by_class = c.execute(
                "SELECT classification, COUNT(*) n FROM events GROUP BY classification ORDER BY n DESC"
            ).fetchall()
            by_risk = c.execute(
                "SELECT risk_level, COUNT(*) n FROM events GROUP BY risk_level"
            ).fetchall()
            avg_ms, max_ms = c.execute(
                "SELECT AVG(response_time_ms), MAX(response_time_ms) FROM events"
            ).fetchone()
            blocks = c.execute("SELECT COUNT(*) FROM blocked_ips").fetchone()[0]
            terminated = c.execute(
                "SELECT COUNT(*) FROM audit_log WHERE action = 'TERMINATE_SESSION'"
            ).fetchone()[0]
        return {
            "generated_at": self._now(),
            "total_events": total,
            "by_class": {r[0]: r[1] for r in by_class},
            "by_risk": {r[0]: r[1] for r in by_risk},
            "avg_response_ms": round(avg_ms or 0, 2),
            "max_response_ms": round(max_ms or 0, 2),
            "firewall_rules": blocks,
            "sessions_terminated": terminated,
        }

    def export_events(self, limit: int = 1000) -> list:
        with self._conn() as c:
            rows = c.execute(
                "SELECT ts, ip, endpoint, method, classification, risk_score, risk_level, "
                "mitre_id, response_status, response_time_ms FROM events ORDER BY ts DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    # ---------------- firewall ---------------- #
    def save_block(self, rec: dict):
        with self._conn() as c:
            c.execute(
                "INSERT OR REPLACE INTO blocked_ips VALUES (?,?,?,?,?,?,?)",
                (rec["ip"], rec["blocked_at"], rec["reason"], rec["attack_type"],
                 rec["risk_score"], 1 if rec["auto_blocked"] else 0, rec["status"]),
            )

    def delete_block(self, ip: str):
        with self._conn() as c:
            c.execute("DELETE FROM blocked_ips WHERE ip = ?", (ip,))

    def load_blocks(self) -> list:
        with self._conn() as c:
            rows = c.execute("SELECT * FROM blocked_ips").fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["auto_blocked"] = bool(d["auto_blocked"])
            out.append(d)
        return out

    # ---------------- audit trail ---------------- #
    def log_audit(self, actor: str, action: str, target: str = "", detail: str = ""):
        with self._conn() as c:
            c.execute(
                "INSERT INTO audit_log (ts, actor, action, target, detail) VALUES (?,?,?,?,?)",
                (self._now(), actor, action, target, detail),
            )

    def get_audit(self, limit: int = 100) -> list:
        with self._conn() as c:
            rows = c.execute(
                "SELECT ts, actor, action, target, detail FROM audit_log ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def clear_runtime_data(self):
        """Clears events, firewall rules and audit trail (users are kept)."""
        with self._conn() as c:
            c.execute("DELETE FROM events")
            c.execute("DELETE FROM blocked_ips")
            c.execute("DELETE FROM audit_log")
