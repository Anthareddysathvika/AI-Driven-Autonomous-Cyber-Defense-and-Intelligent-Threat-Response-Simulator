"""
Security event ingestion pipeline.
Sliding-window tracking -> firewall pre-filter -> AI detection -> autonomous response
-> storage and broadcast. Kept outside app.py so it can be tested and evaluated
without starting the web server.
"""

import time
import uuid


class SecurityPipeline:
    def __init__(self, ai_engine, telemetry, defense, db=None, on_event=None):
        self.ai = ai_engine
        self.telemetry = telemetry
        self.defense = defense
        self.db = db
        self.on_event = on_event  # callback used to broadcast to the dashboard (SSE)

    @staticmethod
    def _base_record(raw: dict) -> dict:
        return {
            "id": str(uuid.uuid4())[:8],
            "timestamp": time.strftime("%H:%M:%S"),
            "full_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "ip": raw.get("ip", "127.0.0.1"),
            "endpoint": raw.get("endpoint", "/"),
            "method": raw.get("method", "GET"),
            "payload": raw.get("payload", ""),
            "user": raw.get("user", "anonymous"),
            "session_id": raw.get("session_id"),
            "user_agent": raw.get("user_agent", "Standard Client"),
        }

    def process(self, raw_event: dict) -> dict:
        start = time.perf_counter()
        ip = raw_event.get("ip", "127.0.0.1")

        # 1. Update sliding-window context for the source address
        self.telemetry.track_request(ip, raw_event.get("endpoint", "/"),
                                     is_failed_login=raw_event.get("is_failed_login", False))
        context = self.telemetry.get_historical_context(ip)

        record = self._base_record(raw_event)

        # 2. Perimeter firewall pre-filter: banned IPs are dropped without running the models
        if self.defense.is_ip_blocked(ip):
            record.update({
                "classification": "DROPPED_HOST", "confidence": 100.0,
                "risk_score": 95, "risk_level": "CRITICAL", "anomaly_score": 1.0,
                "reasons": [f"Host {ip} was previously blocked by the autonomous defense. Packet dropped at the perimeter."],
                "features": {},
                "mitre": {"id": "M1037", "name": "Filter Network Traffic", "tactic": "Mitigation"},
                "actions_taken": [{
                    "action": "DROPPED", "target": ip, "status": "ENFORCED",
                    "description": f"Traffic from blocked IP {ip} dropped at the border firewall",
                }],
                "response_status": "BLOCKED_DROPPED", "http_status": 403,
            })
        else:
            # 3. AI threat detection   4. Autonomous response
            analysis = self.ai.analyze_event(raw_event, context)
            outcome = self.defense.evaluate_and_respond(raw_event, analysis)
            record.update({
                "classification": analysis["predicted_class"],
                "confidence": analysis["confidence"],
                "risk_score": analysis["risk_score"],
                "risk_level": analysis["risk_level"],
                "anomaly_score": analysis["anomaly_score"],
                "reasons": analysis["reasons"],
                "features": analysis["features"],
                "mitre": analysis["mitre"],
                "actions_taken": outcome["actions"],
                "response_status": outcome["status"],
                "incident_id": outcome.get("incident_id"),
                "http_status": outcome["http_status"],
                "policy_mode": outcome.get("policy_mode", "AUTONOMOUS"),
            })

        record["response_time_ms"] = max(0.05, round((time.perf_counter() - start) * 1000, 2))

        # 5. Store, audit and broadcast
        self.telemetry.record_event(record)
        if self.db:
            self.db.save_event(record)
            for act in record["actions_taken"]:
                if act["action"] not in ("ALLOW", "DROPPED"):
                    self.db.log_audit("SYSTEM", act["action"], act.get("target", ""),
                                      f"{record['classification']} risk={record['risk_score']} "
                                      f"[{act.get('status')}] {act.get('description', '')}"[:300])
        if self.on_event:
            self.on_event(record)
        return record
