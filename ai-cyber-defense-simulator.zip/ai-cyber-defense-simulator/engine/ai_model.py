"""
AI & Machine Learning Threat Detection Engine
Combines:
1. Feature Extraction (Entropy, token analysis, rate analysis, payload metrics)
2. Supervised Attack Classification (Random Forest / Decision Tree)
3. Unsupervised Anomaly Detection (Isolation Forest)
4. Explainable Hybrid Risk Scoring & MITRE ATT&CK Mapping
"""

import math
import re
import numpy as np
from sklearn.ensemble import RandomForestClassifier, IsolationForest

class ThreatDetectionEngine:
    def __init__(self):
        # Known signatures / heuristics for feature extraction
        self.sqli_patterns = [
            r"(\bunion(\s+all)?\s+select\b)",
            r"(\bselect\b.+\bfrom\b|\binsert\s+into\b|\bdelete\s+from\b|\bdrop\s+(table|database)\b|\bupdate\b.+\bset\b|\balter\s+table\b|\btruncate\s+table\b)",
            r"(\b(or|and)\b\s+['\"]?\d+['\"]?\s*=\s*['\"]?\d+)",
            r"(--|/\*|\*/|'\s*#)",
            r"(\bexec(\s|\+)+(s|x)p\w+)",
            r"(\bbenchmark\s*\(|\bsleep\s*\()"
        ]
        self.xss_patterns = [
            r"<script\b[^>]*>(.*?)</script>",
            r"(javascript\s*:|vbscript\s*:)",
            r"(onload|onerror|onclick|onmouseover|onfocus)\s*=",
            r"<img\b[^>]*src\s*=\s*['\"]?x['\"]?",
            r"<svg\b[^>]*onload\s*=",
            r"alert\s*\(|eval\s*\("
        ]
        self.path_traversal_patterns = [
            r"(\.\./|\.\.\\|\.\.%2f|\.\.%5c)",
            r"(/etc/passwd|/etc/shadow|/proc/self|/windows/system32|win\.ini|boot\.ini)",
            r"(c:\\windows|c:\\boot)"
        ]
        self.cmd_injection_patterns = [
            r"(;|\||&&|\bexec\b|\bsystem\b|\bpopen\b)\s*(whoami|net user|cat /etc|id|uname|powershell|cmd\.exe|wget|curl)"
        ]

        # Sensitive endpoints that warrant higher threat risk if probed
        self.sensitive_endpoints = [
            "/api/v1/auth/login",
            "/api/v1/admin",
            "/api/v1/users",
            "/admin",
            "/.env",
            "/config",
            "/actuator",
            "/api/v1/transfer",
            "/wp-login.php"
        ]

        # Train baseline ML models
        self._init_models()

    def _calculate_entropy(self, text: str) -> float:
        """Computes Shannon entropy of string to detect obfuscated or encoded payloads."""
        if not text:
            return 0.0
        prob = [float(text.count(c)) / len(text) for c in dict.fromkeys(list(text))]
        entropy = -sum([p * math.log(p) / math.log(2.0) for p in prob if p > 0])
        return round(entropy, 3)

    def extract_features(self, event: dict, historical_context: dict = None) -> dict:
        """
        Extracts structural, lexical, and behavioral features from an incoming request event.
        """
        historical_context = historical_context or {}
        payload = str(event.get("payload", "") or "")
        endpoint = str(event.get("endpoint", "") or "")
        method = str(event.get("method", "GET")).upper()
        
        # Lexical & payload properties
        payload_len = len(payload)
        entropy = self._calculate_entropy(payload)
        
        # Special character ratio
        special_chars = set("!@#$%^&*()_+-=[]{}|;:'\",.<>?/\\`~")
        special_count = sum(1 for c in payload if c in special_chars)
        special_ratio = round(special_count / max(payload_len, 1), 3)

        # Signature hits
        sqli_hits = sum(1 for pat in self.sqli_patterns if re.search(pat, payload, re.IGNORECASE))
        xss_hits = sum(1 for pat in self.xss_patterns if re.search(pat, payload, re.IGNORECASE))
        path_hits = sum(1 for pat in self.path_traversal_patterns if re.search(pat, payload, re.IGNORECASE))
        cmd_hits = sum(1 for pat in self.cmd_injection_patterns if re.search(pat, payload, re.IGNORECASE))

        # Behavioral & sliding-window rates from historical context
        req_rate_10s = float(historical_context.get("req_rate_10s", 1.0))
        failed_logins_30s = int(historical_context.get("failed_logins_30s", 0))
        unique_endpoints_10s = int(historical_context.get("unique_endpoints_10s", 1))
        
        is_sensitive = 1.0 if any(endpoint.startswith(se) for se in self.sensitive_endpoints) else 0.0
        is_post = 1.0 if method == "POST" else 0.0

        return {
            "payload_length": payload_len,
            "entropy": entropy,
            "special_ratio": special_ratio,
            "sqli_hits": sqli_hits,
            "xss_hits": xss_hits,
            "path_hits": path_hits,
            "cmd_hits": cmd_hits,
            "req_rate_10s": req_rate_10s,
            "failed_logins_30s": failed_logins_30s,
            "unique_endpoints_10s": unique_endpoints_10s,
            "is_sensitive": is_sensitive,
            "is_post": is_post
        }

    def _features_to_vector(self, feat: dict) -> list:
        return [
            feat["payload_length"],
            feat["entropy"],
            feat["special_ratio"],
            feat["sqli_hits"],
            feat["xss_hits"],
            feat["path_hits"],
            feat["cmd_hits"],
            feat["req_rate_10s"],
            feat["failed_logins_30s"],
            feat["unique_endpoints_10s"],
            feat["is_sensitive"],
            feat["is_post"]
        ]

    def _init_models(self):
        """
        Initializes and trains the Random Forest classifier and Isolation Forest
        using a robust synthetic cybersecurity dataset representing real-world attack vectors.
        """
        self.class_labels = [
            "BENIGN",
            "BRUTE_FORCE",
            "SQL_INJECTION",
            "XSS",
            "PATH_TRAVERSAL",
            "DDOS_FLOOD",
            "RECON_SCAN"
        ]

        X_train = []
        y_train = []

        # Generate synthetic calibration samples for each class
        np.random.seed(42)

        # 1. BENIGN: Low rates, low entropy, low special char, zero exploit hits
        for i in range(320):
            structured = i % 4 == 3  # ~25% are JSON / form bodies with many punctuation marks
            payload_len = np.random.randint(20, 140) if structured else np.random.randint(5, 80)
            entropy = np.random.uniform(2.5, 4.2) if structured else np.random.uniform(1.5, 3.8)
            special_ratio = np.random.uniform(0.10, 0.34) if structured else np.random.uniform(0.0, 0.15)
            req_rate = np.random.uniform(0.1, 2.5)
            failed_logins = np.random.choice([0, 1], p=[0.95, 0.05])
            unique_ep = np.random.randint(1, 3)
            is_sens = np.random.choice([0.0, 1.0], p=[0.7, 0.3])
            is_post = np.random.choice([0.0, 1.0], p=[0.6, 0.4])
            X_train.append([payload_len, entropy, special_ratio, 0, 0, 0, 0, req_rate, failed_logins, unique_ep, is_sens, is_post])
            y_train.append("BENIGN")

        # 2. BRUTE_FORCE: High failed logins in window, sensitive endpoint, variable velocity
        for _ in range(140):
            payload_len = np.random.randint(15, 60)
            entropy = np.random.uniform(2.5, 4.2)
            special_ratio = np.random.uniform(0.05, 0.25)
            req_rate = np.random.uniform(0.2, 18.0)
            failed_logins = np.random.randint(3, 30)
            unique_ep = 1
            is_sens = 1.0
            is_post = 1.0
            X_train.append([payload_len, entropy, special_ratio, 0, 0, 0, 0, req_rate, failed_logins, unique_ep, is_sens, is_post])
            y_train.append("BRUTE_FORCE")

        # 3. SQL_INJECTION: High SQL tokens, high special ratio, moderate payload length
        for _ in range(120):
            payload_len = np.random.randint(25, 250)
            entropy = np.random.uniform(3.5, 5.2)
            special_ratio = np.random.uniform(0.20, 0.55)
            sqli_hits = np.random.randint(1, 5)
            req_rate = np.random.uniform(0.5, 5.0)
            failed_logins = 0
            unique_ep = np.random.randint(1, 2)
            is_sens = np.random.choice([0.0, 1.0], p=[0.5, 0.5])
            is_post = np.random.choice([0.0, 1.0], p=[0.4, 0.6])
            X_train.append([payload_len, entropy, special_ratio, sqli_hits, 0, 0, 0, req_rate, failed_logins, unique_ep, is_sens, is_post])
            y_train.append("SQL_INJECTION")

        # 4. XSS: High XSS tokens, brackets and script tags, higher special ratio
        for _ in range(120):
            payload_len = np.random.randint(30, 300)
            entropy = np.random.uniform(3.8, 5.5)
            special_ratio = np.random.uniform(0.22, 0.60)
            xss_hits = np.random.randint(1, 4)
            req_rate = np.random.uniform(0.5, 4.0)
            failed_logins = 0
            unique_ep = 1
            is_sens = np.random.choice([0.0, 1.0], p=[0.6, 0.4])
            is_post = np.random.choice([0.0, 1.0], p=[0.3, 0.7])
            X_train.append([payload_len, entropy, special_ratio, 0, xss_hits, 0, 0, req_rate, failed_logins, unique_ep, is_sens, is_post])
            y_train.append("XSS")

        # 5. PATH_TRAVERSAL: Path traversal patterns like ../..
        for _ in range(100):
            payload_len = np.random.randint(20, 150)
            entropy = np.random.uniform(2.8, 4.6)
            special_ratio = np.random.uniform(0.25, 0.50)
            path_hits = np.random.randint(1, 4)
            req_rate = np.random.uniform(0.5, 5.0)
            failed_logins = 0
            unique_ep = np.random.randint(1, 3)
            is_sens = np.random.choice([0.0, 1.0], p=[0.5, 0.5])
            is_post = 0.0
            X_train.append([payload_len, entropy, special_ratio, 0, 0, path_hits, 0, req_rate, failed_logins, unique_ep, is_sens, is_post])
            y_train.append("PATH_TRAVERSAL")

        # 6. DDOS_FLOOD: Extremely high request rate from same source, small to medium payloads
        for _ in range(120):
            payload_len = np.random.randint(5, 100)
            entropy = np.random.uniform(1.8, 4.0)
            special_ratio = np.random.uniform(0.0, 0.20)
            req_rate = np.random.uniform(25.0, 120.0)  # Huge burst!
            failed_logins = 0
            unique_ep = np.random.randint(1, 4)
            is_sens = np.random.choice([0.0, 1.0], p=[0.5, 0.5])
            is_post = np.random.choice([0.0, 1.0], p=[0.5, 0.5])
            X_train.append([payload_len, entropy, special_ratio, 0, 0, 0, 0, req_rate, failed_logins, unique_ep, is_sens, is_post])
            y_train.append("DDOS_FLOOD")

        # 7. RECON_SCAN: High number of distinct endpoints scanned within 10s
        for _ in range(100):
            payload_len = np.random.randint(0, 30)
            entropy = np.random.uniform(1.2, 3.5)
            special_ratio = np.random.uniform(0.0, 0.20)
            req_rate = np.random.uniform(5.0, 25.0)
            failed_logins = 0
            unique_ep = np.random.randint(5, 20)  # Scanning multiple endpoints
            is_sens = 1.0
            is_post = 0.0
            X_train.append([payload_len, entropy, special_ratio, 0, 0, 0, 0, req_rate, failed_logins, unique_ep, is_sens, is_post])
            y_train.append("RECON_SCAN")

        X_train = np.array(X_train)

        # Train Supervised Random Forest
        self.rf_classifier = RandomForestClassifier(n_estimators=45, max_depth=8, random_state=42)
        self.rf_classifier.fit(X_train, y_train)

        # Train Unsupervised Isolation Forest on Benign baseline distribution
        benign_indices = [i for i, y in enumerate(y_train) if y == "BENIGN"]
        X_benign = X_train[benign_indices]
        self.isolation_forest = IsolationForest(n_estimators=50, contamination=0.03, random_state=42)
        self.isolation_forest.fit(X_benign)

    def analyze_event(self, event: dict, historical_context: dict = None) -> dict:
        """
        Runs the full AI threat analysis pipeline on an incoming event:
        - Feature Extraction
        - Random Forest Classification + Confidence
        - Isolation Forest Anomaly Scoring
        - Dynamic Risk Score Computation (0 - 100)
        - Threat Categorization & MITRE ATT&CK Mapping
        - Explainable Evidence Summary
        """
        feats = self.extract_features(event, historical_context)
        vec = np.array([self._features_to_vector(feats)])

        # 1. Supervised prediction
        predicted_class = self.rf_classifier.predict(vec)[0]
        class_probs = self.rf_classifier.predict_proba(vec)[0]
        class_idx = list(self.rf_classifier.classes_).index(predicted_class)
        confidence = float(class_probs[class_idx]) * 100.0  # percent

        # Security Domain Fusion: Guarantee precision on unambiguous exploit patterns & credential stuffing
        if feats["sqli_hits"] > 0:
            predicted_class = "SQL_INJECTION"
            confidence = max(confidence, 96.5)
        elif feats["xss_hits"] > 0:
            predicted_class = "XSS"
            confidence = max(confidence, 96.0)
        elif feats["path_hits"] > 0:
            predicted_class = "PATH_TRAVERSAL"
            confidence = max(confidence, 95.5)
        elif feats["failed_logins_30s"] >= 3 and feats["is_sensitive"] == 1.0:
            predicted_class = "BRUTE_FORCE"
            confidence = max(confidence, 95.0)
        elif feats["req_rate_10s"] >= 15.0:
            predicted_class = "DDOS_FLOOD"
            confidence = max(confidence, 96.0)
        elif feats["unique_endpoints_10s"] >= 4:
            predicted_class = "RECON_SCAN"
            confidence = max(confidence, 92.0)

        # 2. Unsupervised anomaly scoring (-1.0 is anomalous, 1.0 is normal)
        iso_score = float(self.isolation_forest.decision_function(vec)[0])
        # Map iso_score roughly to 0 (normal) - 1.0 (highly anomalous)
        anomaly_metric = max(0.0, min(1.0, round(0.5 - (iso_score * 1.5), 3)))

        # 3. Explainability observations
        reasons = []
        if feats["sqli_hits"] > 0:
            reasons.append(f"SQL injection syntax pattern detected ({feats['sqli_hits']} signature matches)")
        if feats["xss_hits"] > 0:
            reasons.append(f"Cross-Site Scripting (XSS) payload construct detected ({feats['xss_hits']} script/tag hits)")
        if feats["path_hits"] > 0:
            reasons.append(f"Directory traversal / unauthorized system file reference detected")
        if feats["failed_logins_30s"] >= 3:
            reasons.append(f"High velocity authentication failure rate ({feats['failed_logins_30s']} failed attempts in 30s)")
        if feats["req_rate_10s"] >= 15.0:
            reasons.append(f"Anomalous traffic surge detected ({feats['req_rate_10s']:.1f} req/s vs baseline 1.2 req/s)")
        if feats["unique_endpoints_10s"] >= 4:
            reasons.append(f"Rapid horizontal reconnaissance probing across {feats['unique_endpoints_10s']} distinct endpoints")
        if feats["entropy"] > 4.5:
            reasons.append(f"High payload Shannon entropy ({feats['entropy']:.2f}) indicates obfuscation or shellcode")
        if feats["special_ratio"] > 0.35:
            reasons.append(f"High special character density ({feats['special_ratio']*100:.1f}%) typical of exploit encoding")

        # 4. Composite Risk Score (0-100)
        risk_score = 0
        if predicted_class == "BENIGN":
            # Baseline low risk
            risk_score = int(min(25, max(5, int(anomaly_metric * 30))))
            if not reasons:
                reasons.append("Payload structure and traffic velocity conform to normal baseline profile")
        elif predicted_class == "BRUTE_FORCE":
            base = 65 + min(30, feats["failed_logins_30s"] * 3)
            risk_score = int(min(98, base))
        elif predicted_class == "SQL_INJECTION":
            base = 75 + min(23, feats["sqli_hits"] * 8)
            risk_score = int(min(99, base))
        elif predicted_class == "XSS":
            base = 70 + min(25, feats["xss_hits"] * 10)
            risk_score = int(min(96, base))
        elif predicted_class == "PATH_TRAVERSAL":
            base = 75 + min(20, feats["path_hits"] * 8)
            risk_score = int(min(95, base))
        elif predicted_class == "DDOS_FLOOD":
            base = 70 + min(28, int(feats["req_rate_10s"] * 0.4))
            risk_score = int(min(99, base))
        elif predicted_class == "RECON_SCAN":
            base = 50 + min(30, feats["unique_endpoints_10s"] * 3)
            risk_score = int(min(85, base))

        # Adjust risk level tier
        if risk_score >= 80:
            risk_level = "CRITICAL"
        elif risk_score >= 60:
            risk_level = "HIGH"
        elif risk_score >= 35:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"

        # MITRE ATT&CK Mapping
        mitre_map = {
            "BENIGN": {"id": "N/A", "name": "Normal Operations", "tactic": "Legitimate Traffic"},
            "BRUTE_FORCE": {"id": "T1110", "name": "Brute Force: Credential Stuffing", "tactic": "Credential Access"},
            "SQL_INJECTION": {"id": "T1190", "name": "Exploit Public-Facing Application: SQLi", "tactic": "Initial Access"},
            "XSS": {"id": "T1059.007", "name": "Command and Scripting Interpreter: JavaScript", "tactic": "Execution"},
            "PATH_TRAVERSAL": {"id": "T1083", "name": "File and Directory Discovery", "tactic": "Discovery"},
            "DDOS_FLOOD": {"id": "T1498", "name": "Network Denial of Service: Volumetric Flood", "tactic": "Impact"},
            "RECON_SCAN": {"id": "T1046", "name": "Network Service Discovery / Port Scan", "tactic": "Discovery"}
        }

        return {
            "predicted_class": predicted_class,
            "confidence": round(min(confidence, 100.0), 1),
            "risk_score": risk_score,
            "risk_level": risk_level,
            "anomaly_score": round(anomaly_metric, 3),
            "reasons": reasons,
            "features": feats,
            "mitre": mitre_map.get(predicted_class, mitre_map["BENIGN"])
        }
