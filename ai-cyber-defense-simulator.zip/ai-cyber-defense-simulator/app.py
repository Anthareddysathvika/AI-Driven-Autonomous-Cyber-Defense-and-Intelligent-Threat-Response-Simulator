"""
Flask Application, REST and SSE server
AI-Driven Autonomous Cyber Defense and Intelligent Threat Response Simulator
"""

import csv
import io
import json
import os
import queue
import time
import uuid
from functools import wraps

from flask import (Flask, Response, jsonify, redirect, render_template,
                   request, session, url_for)

from engine import (AttackSimulator, Database, DefenseOrchestrator,
                    SecurityPipeline, TelemetryManager, ThreatDetectionEngine)

app = Flask(__name__)
app.secret_key = os.environ.get("CYBERDEFENSE_SECRET", "change-this-secret-in-production")

# ----------------- core subsystems ----------------- #
db = Database()
db.seed_default_users()
ai_engine = ThreatDetectionEngine()
telemetry_mgr = TelemetryManager(max_events=800)
defense_orchestrator = DefenseOrchestrator(telemetry_mgr, db=db)

sse_subscribers = []


def notify_subscribers(event_data):
    """Pushes an event to every connected Server-Sent Events subscriber."""
    msg = f"data: {json.dumps(event_data)}\n\n"
    for q in list(sse_subscribers):
        try:
            q.put_nowait(msg)
        except Exception:
            if q in sse_subscribers:
                sse_subscribers.remove(q)


pipeline = SecurityPipeline(ai_engine, telemetry_mgr, defense_orchestrator,
                            db=db, on_event=notify_subscribers)
ingestion_pipeline = pipeline.process
simulator = AttackSimulator(ingestion_pipeline=ingestion_pipeline)


def seed_initial_state():
    simulator.run_scenario("benign", count=3)
    simulator.run_scenario("recon_scan", count=1)
    simulator.run_scenario("sql_injection", count=1)


seed_initial_state()

# ----------------- authentication ----------------- #
MAX_FAILED_LOGINS = 5
LOCKOUT_SECONDS = 60
_failed_logins = {}  # ip -> list of timestamps


def _client_ip():
    return request.remote_addr or "127.0.0.1"


def _locked_out(ip):
    now = time.time()
    attempts = [t for t in _failed_logins.get(ip, []) if now - t < LOCKOUT_SECONDS]
    _failed_logins[ip] = attempts
    return len(attempts) >= MAX_FAILED_LOGINS


def current_user():
    """Returns the logged-in user, or None when the session is missing or was revoked."""
    sid = session.get("session_id")
    if not sid:
        return None
    reg = telemetry_mgr.sessions.get(sid)
    if not reg or reg.get("status") != "ACTIVE":
        session.clear()  # revoked by the defense engine or an administrator
        return None
    return {"username": session["username"], "role": session["role"], "session_id": sid}


def login_required(role=None):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = current_user()
            if not user:
                if request.path.startswith("/api/"):
                    return jsonify({"error": "authentication required"}), 401
                return redirect(url_for("login"))
            if role and user["role"] != role:
                db.log_audit(user["username"], "ACCESS_DENIED", request.path, f"requires {role}")
                return jsonify({"error": f"{role.lower()} privileges required"}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html", error=request.args.get("error"))

    ip = _client_ip()
    if _locked_out(ip):
        db.log_audit("anonymous", "LOGIN_LOCKOUT", ip, "too many failed attempts")
        return render_template("login.html", error="Too many failed attempts. Try again in a minute."), 429

    username = request.form.get("username", "").strip()
    user = db.verify_user(username, request.form.get("password", ""))
    if not user:
        _failed_logins.setdefault(ip, []).append(time.time())
        db.log_audit(username or "anonymous", "LOGIN_FAILED", ip, "invalid credentials")
        return render_template("login.html", error="Invalid username or password."), 401

    sid = "sess_" + uuid.uuid4().hex[:10]
    session.clear()
    session.update(session_id=sid, username=user["username"], role=user["role"])
    telemetry_mgr.register_or_update_session(sid, user["username"], ip)
    telemetry_mgr.sessions[sid]["role"] = "Administrator" if user["role"] == "ADMIN" else "System User"
    db.log_audit(user["username"], "LOGIN", ip, f"session {sid}")
    return redirect(url_for("index"))


@app.route("/logout")
def logout():
    sid = session.get("session_id")
    if sid:
        telemetry_mgr.terminate_session(sid, reason="User logout")
        db.log_audit(session.get("username", "?"), "LOGOUT", sid)
    session.clear()
    return redirect(url_for("login"))


@app.route("/api/me")
@login_required()
def me():
    return jsonify(current_user())


# ----------------- dashboard routes ----------------- #
@app.route("/")
@login_required()
def index():
    return render_template("index.html")


@app.route("/api/stream")
@login_required()
def sse_stream():
    """Server-Sent Events endpoint for live streaming to the dashboard."""
    q = queue.Queue(maxsize=100)
    sse_subscribers.append(q)

    def event_stream():
        try:
            yield 'data: {"type": "CONNECTION_ESTABLISHED"}\n\n'
            while True:
                yield q.get()
        except GeneratorExit:
            if q in sse_subscribers:
                sse_subscribers.remove(q)

    return Response(event_stream(), mimetype="text/event-stream")


@app.route("/api/events")
@login_required()
def get_events():
    events = telemetry_mgr.get_events(limit=int(request.args.get("limit", 100)),
                                      filter_type=request.args.get("type", "ALL"),
                                      filter_risk=request.args.get("risk", "ALL"))
    return jsonify({"events": events, "count": len(events)})


@app.route("/api/metrics")
@login_required()
def get_metrics():
    metrics = telemetry_mgr.get_metrics()
    metrics["defense_mode"] = defense_orchestrator.mode
    metrics["blocked_ips_count"] = len(defense_orchestrator.get_blocked_ips())
    metrics["continuous_active"] = simulator.continuous_running
    return jsonify(metrics)


@app.route("/api/simulate/scenario", methods=["POST"])
@login_required()
def simulate_scenario():
    data = request.get_json() or {}
    scenario = data.get("scenario", "benign")
    results = simulator.run_scenario(scenario, count=int(data.get("count", 1)),
                                     custom_ip=data.get("custom_ip"))
    db.log_audit(session["username"], "SIMULATION", scenario, f"{len(results)} events")
    return jsonify({"success": True, "scenario": scenario,
                    "executed_count": len(results), "results": results[:5]})


@app.route("/api/simulate/custom", methods=["POST"])
@login_required()
def simulate_custom():
    d = request.get_json() or {}
    res = simulator.inject_custom(ip=d.get("ip", "192.0.2.77"),
                                  endpoint=d.get("endpoint", "/api/v1/search"),
                                  method=d.get("method", "POST"),
                                  payload=d.get("payload", "' OR 1=1 --"),
                                  user=d.get("user", "custom_actor"),
                                  session_id=d.get("session_id"))
    db.log_audit(session["username"], "CUSTOM_PAYLOAD", d.get("ip", ""), res.get("classification", ""))
    return jsonify({"success": True, "event": res})


@app.route("/api/simulator/continuous", methods=["POST"])
@login_required()
def toggle_continuous_simulation():
    data = request.get_json() or {}
    if data.get("enabled", True):
        simulator.start_continuous(interval_seconds=float(data.get("interval", 1.8)))
    else:
        simulator.stop_continuous()
    return jsonify({"success": True, "continuous_active": simulator.continuous_running})


@app.route("/api/firewall")
@login_required()
def get_firewall():
    blocked = defense_orchestrator.get_blocked_ips()
    return jsonify({"blocked_ips": blocked, "total_blocked": len(blocked)})


# ----------------- administrator-only controls ----------------- #
@app.route("/api/firewall/block", methods=["POST"])
@login_required("ADMIN")
def block_ip_manual():
    data = request.get_json() or {}
    ip = data.get("ip")
    if not ip:
        return jsonify({"error": "IP is required"}), 400
    rec = defense_orchestrator.block_ip(ip, reason=data.get("reason", "Manual administrator enforcement"),
                                        attack_type="MANUAL_ENFORCEMENT", risk_score=90, auto=False)
    db.log_audit(session["username"], "MANUAL_BLOCK", ip)
    return jsonify({"success": True, "rule": rec})


@app.route("/api/firewall/unblock", methods=["POST"])
@login_required("ADMIN")
def unblock_ip():
    ip = (request.get_json() or {}).get("ip")
    if not ip:
        return jsonify({"error": "IP is required"}), 400
    ok = defense_orchestrator.unblock_ip(ip)
    db.log_audit(session["username"], "UNBLOCK", ip)
    return jsonify({"success": ok, "ip": ip})


@app.route("/api/sessions")
@login_required()
def get_sessions():
    return jsonify({"sessions": telemetry_mgr.get_sessions()})


@app.route("/api/sessions/terminate", methods=["POST"])
@login_required("ADMIN")
def terminate_session():
    data = request.get_json() or {}
    sid = data.get("session_id")
    if not sid:
        return jsonify({"error": "session_id required"}), 400
    ok = telemetry_mgr.terminate_session(sid, reason=data.get("reason", "Manual operator termination"))
    db.log_audit(session["username"], "TERMINATE_SESSION", sid, "manual")
    return jsonify({"success": ok, "session_id": sid})


@app.route("/api/sessions/restore", methods=["POST"])
@login_required("ADMIN")
def restore_session():
    sid = (request.get_json() or {}).get("session_id")
    if sid in telemetry_mgr.sessions:
        telemetry_mgr.sessions[sid]["status"] = "ACTIVE"
        db.log_audit(session["username"], "RESTORE_SESSION", sid)
        return jsonify({"success": True, "session_id": sid})
    return jsonify({"error": "Not found"}), 404


@app.route("/api/defense/mode", methods=["POST"])
@login_required("ADMIN")
def set_defense_mode():
    mode = (request.get_json() or {}).get("mode", "AUTONOMOUS").upper()
    ok = defense_orchestrator.set_mode(mode)
    db.log_audit(session["username"], "MODE_CHANGE", mode)
    return jsonify({"success": ok, "mode": defense_orchestrator.mode})


@app.route("/api/system/reset", methods=["POST"])
@login_required("ADMIN")
def system_reset():
    simulator.stop_continuous()
    telemetry_mgr.reset()
    defense_orchestrator.clear_firewall()
    seed_initial_state()
    db.log_audit(session["username"], "SYSTEM_RESET")
    return jsonify({"success": True, "message": "System state reset successfully"})


@app.route("/api/users", methods=["GET", "POST"])
@login_required("ADMIN")
def manage_users():
    if request.method == "GET":
        return jsonify({"users": db.list_users()})
    d = request.get_json() or {}
    ok = db.create_user(d.get("username", ""), d.get("password", ""), d.get("role", "USER"))
    if ok:
        db.log_audit(session["username"], "CREATE_USER", d.get("username"), d.get("role", "USER"))
    return jsonify({"success": ok}), (200 if ok else 400)


# ----------------- audit and reports ----------------- #
@app.route("/api/audit")
@login_required()
def get_audit():
    return jsonify({"audit": db.get_audit(limit=int(request.args.get("limit", 100)))})


@app.route("/api/report")
@login_required()
def get_report():
    return jsonify(db.event_summary())


@app.route("/api/report/download")
@login_required()
def download_report():
    rows = db.export_events()
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()) if rows else ["ts"])
    writer.writeheader()
    writer.writerows(rows)
    db.log_audit(session["username"], "REPORT_EXPORT", "events.csv", f"{len(rows)} rows")
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=security_report.csv"})


if __name__ == "__main__":
    print("=" * 65)
    print("AI-Driven Autonomous Cyber Defense and Intelligent Threat Response Simulator")
    print("Open http://127.0.0.1:5000   (admin / Admin@123  or  analyst / Analyst@123)")
    print("=" * 65)
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
