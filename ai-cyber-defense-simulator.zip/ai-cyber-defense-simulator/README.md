# AI-Driven Autonomous Cyber Defense and Intelligent Threat Response Simulator

An advanced cybersecurity software application and simulation platform designed to detect and respond to modern cyber threats in a safe, controlled virtual environment using Artificial Intelligence, Machine Learning, and Autonomous SOAR (Security Orchestration, Automation, and Response) mechanics.

---

## 🎯 Project Overview & Problem Statement

In traditional security operations centers (SOC) and legacy intrusion detection systems (IDS/IPS):
- Threats are identified using **rigid, fixed signature rules** that fail against zero-day exploits, polymorphism, and credential abuse.
- Security triage requires **slow manual analyst monitoring**, leading to alert fatigue and prolonged Mean Time To Detect (MTTD) and Mean Time To Respond (MTTR).
- Organizations lack safe test environments where attack situations can be safely practiced without impacting production workloads.

**The Solution:**
This project provides a complete virtual environment where cyberattack scenarios—such as high-frequency brute-force login attempts, malicious web injection vectors (SQLi, XSS, Path Traversal), and volumetric network floods (DDoS)—are safely simulated. 

The system continuously inspects ingested traffic using a **Hybrid AI/ML Engine** (Random Forest Classifier + Unsupervised Isolation Forest Anomaly Detector) to evaluate risk in milliseconds. Depending on the detected threat level, the system **autonomously executes containment actions**, such as:
1. **Dynamic Firewall IP Blocking**: Instantly drops traffic from the attacker's source address at the perimeter gateway.
2. **Session Revocation & Termination**: Invalidates active bearer tokens for compromised or hijacked accounts.
3. **SIEM Security Incident Dispatch**: Automatically generates structured alert records with MITRE ATT&CK technique classifications and explainable reasoning.
4. **Adaptive Rate Limiting & Throttling**: Injects synthetic latency to neutralize horizontal reconnaissance scans.

---

## 🏗️ System Architecture

```
                    +------------------------------------------------------+
                    |      Virtual Threat & Attack Scenario Generator      |
                    |  (Brute Force, SQLi, XSS, Path Traversal, DDoS, ...) |
                    +--------------------------+---------------------------+
                                               |
                                               v
+--------------------------------------------------------------------------------------------------+
|                              INGESTION & TELEMETRY PIPELINE                                      |
|  - Stateful Sliding-Window Rate Tracker (Velocity, Failure Bursts, Distinct Endpoints)           |
|  - Perimeter Firewall Pre-Filter (Drops traffic from currently banned IPs)                       |
+----------------------------------------------+---------------------------------------------------+
                                               |
                                               v
+--------------------------------------------------------------------------------------------------+
|                               HYBRID AI/ML DETECTION ENGINE                                      |
|  [Feature Extractor]                                                                             |
|    - Shannon Entropy, Special-character density, Keyword tokens, Sliding-window velocity        |
|  [Supervised Classifier: Random Forest]                                                          |
|    - Multi-class signature & behavioral classification (Brute Force, SQLi, XSS, Recon, ...)      |
|  [Unsupervised Anomaly Detector: Isolation Forest]                                               |
|    - Out-of-distribution volumetric surges & novel anomaly scoring                               |
|  [Risk Engine & Explainability]                                                                  |
|    - Dynamic Risk Score (0-100), Risk Tier (LOW / MEDIUM / HIGH / CRITICAL), MITRE ATT&CK Map    |
+----------------------------------------------+---------------------------------------------------+
                                               |
                                               v
+--------------------------------------------------------------------------------------------------+
|                       AUTONOMOUS DEFENSE & SOAR ORCHESTRATOR                                     |
|  - Policy Engine: Autonomous Mode (Zero-Touch) vs. Advisory Mode (Human-in-the-Loop)             |
|  - Actions: Dynamic IP Ban, Session Invalidation, SIEM Alerts, Synthetic Latency                 |
+----------------------------------------------+---------------------------------------------------+
                                               |
                                               v
+--------------------------------------------------------------------------------------------------+
|                            REAL-TIME CYBER DEFENSE DASHBOARD                                     |
|  - Live Streaming Threat Feed (Server-Sent Events: SSE)                                          |
|  - Threat Matrix DEFCON Indicator & measured Autonomous MTTR counter                             |
|  - Interactive Scenario Launchpad & Custom Exploit Payload Injector                              |
|  - Real-Time Time-Series & Category Distribution Analytics (Chart.js)                            |
|  - Dynamic Firewall Management & Session Registry Operations                                     |
|  - Deep-Dive Explainable AI (XAI) Incident Forensics Modal                                       |
+--------------------------------------------------------------------------------------------------+
```

---

## ⚡ Key Features

- **Safe Virtual Attack Simulator**:
  - **Repeated Login Attempts (Brute Force / Credential Stuffing)**: High-frequency password attempts against `/api/v1/auth/login`.
  - **Suspicious SQL Injection**: Payloads with `UNION SELECT`, `OR 1=1`, and comment truncations.
  - **Cross-Site Scripting (XSS)**: Malicious script tags and cookie exfiltration vectors.
  - **Directory Traversal**: Unauthorized `../../etc/passwd` path climbing attempts.
  - **Volumetric Network DDoS Flood**: Sudden bursts of 25+ requests testing anomaly thresholds.
  - **Reconnaissance Probing**: Rapid horizontal sweeping of sensitive debug endpoints (`/.env`, `/wp-login.php`, `/actuator`).
  - **Legitimate Benign Traffic**: Realistic user traffic verifying zero false-positive precision.
  - **Custom Vector Crafting**: Test any custom IP, method, endpoint, and payload string on demand.
- **Explainable AI (XAI)**:
  - Transparent decision breakdown: Shannon entropy calculations, special character ratios, velocity anomalies, and MITRE ATT&CK technique IDs (e.g. `T1110`, `T1190`, `T1059`, `T1498`).
- **Autonomous & Advisory Dual Modes**:
  - **Autonomous Mode**: System instantaneously applies defensive countermeasures without waiting for human intervention.
  - **Advisory Mode**: Generates incident recommendations for security analysts who can inspect and execute actions manually.
- **Ultra-Fast MTTR**:
  - Measured mean response time is about **7 milliseconds** per event (see `evaluate.py`), compared to typical human analyst response times of 15–45 minutes.

---

## 🚀 Getting Started

### Prerequisites
- Python 3.10+ (Python 3.13 supported)
- Modern web browser (Chrome, Edge, Firefox, Safari)

### Installation

1. Navigate to the project directory:
```bash
cd ai-cyber-defense-simulator
```

2. Install dependencies (if not already installed in your Python environment):
```bash
pip install -r requirements.txt
```

### Running the Application

Start the Cyber Defense Operations Center:
```bash
python app.py
```

The web console will be available at:
👉 **`http://localhost:5000`** (or `http://127.0.0.1:5000`)

### Login and roles

| Username | Password | Role | Permissions |
|----------|----------|------|-------------|
| `admin` | `Admin@123` | Administrator | Everything, including operating mode, manual firewall bans, session control, reset and user management (`/api/users`) |
| `analyst` | `Analyst@123` | System User | Run simulations, view threats, firewall, sessions, audit trail and download reports |

Passwords are stored as salted hashes in the SQLite database (`cyberdefense.db`, created on first run).
After 5 failed logins from one address the login is locked for 60 seconds. If the defense engine
revokes a user's session, that user is signed out on the next request. Change the demo passwords
and set `CYBERDEFENSE_SECRET` before using the project anywhere other than a lab.

### Database, audit trail and reports
Events, firewall rules, users and the audit trail are stored in SQLite. The **Audit & Reports** tab shows
the audit trail and a summary, and **Download CSV Report** exports the stored events.

### Evaluation and tests
```bash
python evaluate.py              # detection / containment / false-positive evaluation -> evaluation_results.json
python -m unittest test_simulator -v   # 17 unit and API tests
```

---

## 🔬 Demonstration Walkthrough

1. **Observe the Command Center**:
   - Open `http://localhost:5000` in your web browser.
   - Note the real-time DEFCON indicator (`NORMAL`), active telemetry counters, and the live stream.
2. **Simulate a Brute Force Attack**:
   - In the left deck, click **"Brute Force Login"**.
   - Notice how multiple authentication failure events arrive in quick succession.
   - The AI identifies high failed login velocity, escalates the Risk Score to `CRITICAL`, and the Defense Orchestrator **autonomously blacklists the attacker IP**.
   - Subsequent requests from that IP are instantly dropped at the perimeter firewall.
3. **Simulate a Web Exploit (SQLi or XSS)**:
   - Click **"SQL Injection (SQLi)"** or **"Cross-Site Scripting (XSS)"**.
   - Observe the system identifying the syntactic exploit structure, elevating risk to `HIGH/CRITICAL`, and **terminating the user's active session token** to stop lateral movement.
4. **Test Benign Legitimate Traffic**:
   - Click **"Legitimate Benign Traffic"**.
   - Observe how the AI accurately classifies normal browsing and queries as `BENIGN` with `LOW` risk (5–15/100) and executes an `ALLOW` action without false alarms.
5. **Inspect Deep-Dive AI Forensics**:
   - Click **"Inspect"** on any event in the live feed.
   - Review the calculated Shannon Entropy, special character density, MITRE ATT&CK mapping, explainability notes, and the autonomous action timeline.
6. **Firewall & Session Management**:
   - Switch to the **"Perimeter Firewall"** tab to view currently banned IPs and test the "Release Ban" feature.
   - Switch to the **"Session Registry"** tab to view revoked vs. active tokens.
7. **Background Continuous Traffic**:
   - Click **"Bot Traffic: OFF"** in the top bar to toggle it to **"ON"**.
   - The simulator will generate a continuous stream of realistic background traffic mixed with periodic attack vectors for live demo presentations.

---

## 🛡️ MITRE ATT&CK Techniques Mapped

| Attack Vector | MITRE Technique ID | Technique Name | Tactic |
|---|---|---|---|
| Brute Force | `T1110` | Brute Force: Credential Stuffing | Credential Access |
| SQL Injection | `T1190` | Exploit Public-Facing Application | Initial Access |
| Cross-Site Scripting | `T1059.007` | JavaScript Interpreter | Execution |
| Directory Traversal | `T1083` | File and Directory Discovery | Discovery |
| DDoS Flood | `T1498` | Network Denial of Service | Impact |
| Reconnaissance Sweep | `T1046` | Network Service Discovery | Discovery |

---

## 💻 Tech Stack
- **Backend**: Python 3.13, Flask 3.1, NumPy, Pandas, Scikit-Learn (Random Forest, Isolation Forest).
- **Communication**: Server-Sent Events (SSE) for low-overhead real-time event streaming.
- **Frontend**: HTML5, CSS3 Glassmorphism theme, Vanilla JavaScript, Chart.js 4.x, Web Audio API.


---

## 📁 Project Structure

```
app.py                      Flask app: login, roles, REST + SSE routes, reports
engine/simulator.py         Attack and normal-traffic scenarios
engine/telemetry.py         Sliding-window tracking, event buffer, session registry
engine/ai_model.py          Features, Random Forest, Isolation Forest, risk score, MITRE map
engine/defense_orchestrator.py  Autonomous / advisory response and firewall
engine/pipeline.py          Ingestion pipeline (detect -> respond -> store -> broadcast)
engine/database.py          SQLite: users, events, firewall rules, audit trail
templates/ static/          Login page and dashboard (HTML, CSS, JavaScript, Chart.js)
evaluate.py                 Performance evaluation
test_simulator.py           Unit and API tests
```
