"""
Autonomous Cyber Defense & SOAR (Security Orchestration, Automation, and Response) Engine
Executes automated countermeasures:
1. Dynamic Firewall IP Blocking
2. Rogue / Compromised Session Termination
3. Security Incident Alert Dispatch (SIEM Incident Record)
4. Synthetic Rate Limiting & Throttling
Supports both Full Autonomous Mode and Advisory (Human-in-the-loop) Mode.
"""

import time
import uuid
from threading import Lock

class DefenseOrchestrator:
    def __init__(self, telemetry_mgr):
        self.lock = Lock()
        self.telemetry = telemetry_mgr
        
        # Defense operating mode: 'AUTONOMOUS' or 'ADVISORY'
        self.mode = "AUTONOMOUS"

        # Active firewall table: ip -> dict
        self.blocked_ips = {}

        # Rate limited IPs: ip -> float (expire timestamp)
        self.rate_limited_ips = {}

        # Incident counter
        self.incident_seq = 1000

    def set_mode(self, mode: str):
        """Switches between AUTONOMOUS and ADVISORY operational modes."""
        with self.lock:
            if mode in ["AUTONOMOUS", "ADVISORY"]:
                self.mode = mode
                return True
            return False

    def is_ip_blocked(self, ip: str) -> bool:
        """Checks if IP is currently banned on the simulated firewall."""
        with self.lock:
            return ip in self.blocked_ips

    def block_ip(self, ip: str, reason: str, attack_type: str = "MANUAL", risk_score: int = 80, auto: bool = True) -> dict:
        """Bans an IP address at the simulated perimeter gateway."""
        with self.lock:
            record = {
                "ip": ip,
                "blocked_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "reason": reason,
                "attack_type": attack_type,
                "risk_score": risk_score,
                "auto_blocked": auto,
                "status": "ENFORCED"
            }
            self.blocked_ips[ip] = record
            return record

    def unblock_ip(self, ip: str) -> bool:
        """Removes an IP address from the firewall blocklist."""
        with self.lock:
            if ip in self.blocked_ips:
                del self.blocked_ips[ip]
                return True
            return False

    def get_blocked_ips(self) -> list:
        """Returns all currently blocked IPs."""
        with self.lock:
            return list(self.blocked_ips.values())

    def clear_firewall(self):
        """Clears all firewall rules."""
        with self.lock:
            self.blocked_ips.clear()
            self.rate_limited_ips.clear()

    def evaluate_and_respond(self, raw_event: dict, ai_analysis: dict) -> dict:
        """
        Orchestrates autonomous threat containment based on ML risk assessment and policy rules.
        """
        ip = raw_event.get("ip", "0.0.0.0")
        session_id = raw_event.get("session_id")
        user = raw_event.get("user", "anonymous")
        endpoint = raw_event.get("endpoint", "/")
        payload = raw_event.get("payload", "")
        method = raw_event.get("method", "GET")

        risk_score = ai_analysis.get("risk_score", 0)
        risk_level = ai_analysis.get("risk_level", "LOW")
        pred_class = ai_analysis.get("predicted_class", "BENIGN")
        mitre = ai_analysis.get("mitre", {})

        actions_taken = []
        is_blocked_already = self.is_ip_blocked(ip)

        # 1. Perimeter Check: If IP is already blocked, drop packet immediately
        if is_blocked_already:
            actions_taken.append({
                "action": "DROPPED",
                "target": ip,
                "description": f"Perimeter Gateway dropped incoming packet from blacklisted IP {ip}",
                "status": "ENFORCED"
            })
            return {
                "status": "BLOCKED_DROPPED",
                "http_status": 403,
                "actions": actions_taken,
                "policy_mode": self.mode
            }

        # 2. Benign Traffic Handling
        if pred_class == "BENIGN" and risk_score < 35:
            actions_taken.append({
                "action": "ALLOW",
                "target": ip,
                "description": "Legitimate transaction validated by AI filter. Access granted.",
                "status": "PASSED"
            })
            return {
                "status": "ALLOWED",
                "http_status": 200,
                "actions": actions_taken,
                "policy_mode": self.mode
            }

        # 3. Threat Response Matrix
        with self.lock:
            self.incident_seq += 1
            incident_id = f"INC-{self.incident_seq}"

        # Action A: Security Alert Generation (SIEM Incident)
        alert_desc = f"AI flagged {pred_class} attempt from {ip} on {endpoint} (Risk: {risk_score}/100)"
        actions_taken.append({
            "action": "SECURITY_ALERT",
            "incident_id": incident_id,
            "severity": risk_level,
            "mitre_technique": f"{mitre.get('id')}: {mitre.get('name')}",
            "target": endpoint,
            "description": alert_desc,
            "status": "DISPATCHED"
        })

        # Action B: Dynamic Firewall IP Block (for High/Critical threats or high-confidence attacks)
        should_block_ip = (risk_score >= 65) or (pred_class in ["BRUTE_FORCE", "SQL_INJECTION", "DDOS_FLOOD", "PATH_TRAVERSAL"])
        if should_block_ip:
            if self.mode == "AUTONOMOUS":
                reason = f"Autonomous block triggered by {pred_class} detection (Risk Score: {risk_score})"
                self.block_ip(ip, reason=reason, attack_type=pred_class, risk_score=risk_score, auto=True)
                actions_taken.append({
                    "action": "BLOCK_IP",
                    "target": ip,
                    "description": f"Firewall Rule Added: Banned IP {ip} at perimeter gateway (0-sec MTTR)",
                    "status": "ENFORCED"
                })
            else:
                actions_taken.append({
                    "action": "BLOCK_IP",
                    "target": ip,
                    "description": f"[ADVISORY] Recommendation to blacklist IP {ip} pending human analyst confirmation",
                    "status": "PENDING_APPROVAL"
                })

        # Action C: Session Termination (if an authenticated session was involved in exploit or hijacking)
        if session_id and (risk_score >= 60 or pred_class in ["SQL_INJECTION", "XSS", "PATH_TRAVERSAL"]):
            if self.mode == "AUTONOMOUS":
                terminated = self.telemetry.terminate_session(session_id, reason=f"Compromised session involved in {pred_class} attempt")
                if terminated:
                    actions_taken.append({
                        "action": "TERMINATE_SESSION",
                        "target": session_id,
                        "user": user,
                        "description": f"Revoked active bearer token & invalidated session {session_id} for user '{user}'",
                        "status": "ENFORCED"
                    })
            else:
                actions_taken.append({
                    "action": "TERMINATE_SESSION",
                    "target": session_id,
                    "user": user,
                    "description": f"[ADVISORY] Recommendation to terminate session {session_id} pending approval",
                    "status": "PENDING_APPROVAL"
                })

        # Action D: Rate Limiting / Traffic Throttling (for Reconnaissance Scans or Moderate Anomaly)
        if pred_class == "RECON_SCAN" and not should_block_ip:
            actions_taken.append({
                "action": "RATE_LIMIT",
                "target": ip,
                "description": f"Synthetic delay injected for IP {ip}. Requests throttled to 1 req/5s.",
                "status": "ENFORCED"
            })

        outcome_status = "AUTONOMOUSLY_CONTAINED" if self.mode == "AUTONOMOUS" else "ADVISORY_ALERTED"
        http_code = 403 if any(a["action"] == "BLOCK_IP" and a["status"] == "ENFORCED" for a in actions_taken) else 400

        return {
            "status": outcome_status,
            "http_status": http_code,
            "actions": actions_taken,
            "incident_id": incident_id,
            "policy_mode": self.mode
        }
