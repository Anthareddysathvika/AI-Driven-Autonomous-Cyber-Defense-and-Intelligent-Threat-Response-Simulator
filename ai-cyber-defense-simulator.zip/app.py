"""
Flask Application & REST / SSE Server
AI-Driven Autonomous Cyber Defense and Intelligent Threat Response Simulator
"""

import time
import json
import uuid
import queue
from flask import Flask, render_template, request, jsonify, Response
from engine import ThreatDetectionEngine, TelemetryManager, DefenseOrchestrator, AttackSimulator

app = Flask(__name__)

# Initialize Core Subsystems
ai_engine = ThreatDetectionEngine()
telemetry_mgr = TelemetryManager(max_events=800)
defense_orchestrator = DefenseOrchestrator(telemetry_mgr)

# SSE subscriber queue list
sse_subscribers = []

def notify_subscribers(event_data):
    """Pushes event data to all connected Server-Sent Events subscribers."""
    dead_subs = []
    msg = f"data: {json.dumps(event_data)}\n\n"
    for q in sse_subscribers:
        try:
            q.put_nowait(msg)
        except Exception:
            dead_subs.append(q)
    for dq in dead_subs:
        if dq in sse_subscribers:
            sse_subscribers.remove(dq)

def ingestion_pipeline(raw_event: dict) -> dict:
    """
    Central Security Event Ingestion & Autonomous Containment Pipeline:
    1. Sliding window rate tracking
    2. Perimeter firewall pre-filter
    3. AI Threat Detection & Machine Learning Risk Classification
    4. Autonomous Defense Response & SOAR action orchestration
    5. Telemetry recording & real-time UI broadcasting
    """
    start_time = time.perf_counter()
    ip = raw_event.get("ip", "127.0.0.1")
    endpoint = raw_event.get("endpoint", "/")
    is_failed_login = raw_event.get("is_failed_login", False)

    # 1. Update sliding window context
    telemetry_mgr.track_request(ip, endpoint, is_failed_login=is_failed_login)
    historical_context = telemetry_mgr.get_historical_context(ip)

    # 2. Check if IP is already banned at perimeter firewall
    if defense_orchestrator.is_ip_blocked(ip):
        elapsed_ms = round((time.perf_counter() - start_time) * 1000, 2)
        event_record = {
            "id": str(uuid.uuid4())[:8],
            "timestamp": time.strftime("%H:%M:%S"),
            "full_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "ip": ip,
            "endpoint": endpoint,
            "method": raw_event.get("method", "GET"),
            "payload": raw_event.get("payload", ""),
            "user": raw_event.get("user", "anonymous"),
            "session_id": raw_event.get("session_id"),
            "user_agent": raw_event.get("user_agent", "Unknown"),
            "classification": "DROPPED_HOST",
            "confidence": 100.0,
            "risk_score": 95,
            "risk_level": "CRITICAL",
            "anomaly_score": 1.0,
            "reasons": [f"Host {ip} was previously blacklisted by Autonomous Cyber Defense. Packet dropped at perimeter gateway."],
            "features": {},
            "mitre": {"id": "T1498", "name": "Network Ingress Filtering", "tactic": "Perimeter Defense"},
            "actions_taken": [{
                "action": "DROPPED",
                "target": ip,
                "description": f"Simulated traffic from banned IP {ip} dropped immediately at border firewall",
                "status": "ENFORCED"
            }],
            "response_status": "BLOCKED_DROPPED",
            "http_status": 403,
            "response_time_ms": max(0.4, elapsed_ms)
        }
        telemetry_mgr.record_event(event_record)
        notify_subscribers(event_record)
        return event_record

    # 3. AI Threat Detection Analysis
    ai_analysis = ai_engine.analyze_event(raw_event, historical_context)

    # 4. Autonomous Defense Response Orchestration (SOAR)
    response_outcome = defense_orchestrator.evaluate_and_respond(raw_event, ai_analysis)

    elapsed_ms = round((time.perf_counter() - start_time) * 1000, 2)

    # 5. Build full incident & event telemetry record
    event_record = {
        "id": str(uuid.uuid4())[:8],
        "timestamp": time.strftime("%H:%M:%S"),
        "full_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "ip": ip,
        "endpoint": endpoint,
        "method": raw_event.get("method", "GET"),
        "payload": raw_event.get("payload", ""),
        "user": raw_event.get("user", "anonymous"),
        "session_id": raw_event.get("session_id"),
        "user_agent": raw_event.get("user_agent", "Standard Client"),
        "classification": ai_analysis["predicted_class"],
        "confidence": ai_analysis["confidence"],
        "risk_score": ai_analysis["risk_score"],
        "risk_level": ai_analysis["risk_level"],
        "anomaly_score": ai_analysis["anomaly_score"],
        "reasons": ai_analysis["reasons"],
        "features": ai_analysis["features"],
        "mitre": ai_analysis["mitre"],
        "actions_taken": response_outcome["actions"],
        "response_status": response_outcome["status"],
        "incident_id": response_outcome.get("incident_id"),
        "http_status": response_outcome["http_status"],
        "policy_mode": response_outcome.get("policy_mode", "AUTONOMOUS"),
        "response_time_ms": max(0.8, elapsed_ms)
    }

    # 6. Store and broadcast
    telemetry_mgr.record_event(event_record)
    notify_subscribers(event_record)

    return event_record

# Initialize Simulator with the active ingestion pipeline
simulator = AttackSimulator(ingestion_pipeline=ingestion_pipeline)

# Seed a few initial events for immediate visual context
def seed_initial_state():
    simulator.run_scenario("benign", count=3)
    simulator.run_scenario("recon_scan", count=1)
    simulator.run_scenario("sql_injection", count=1)

seed_initial_state()

# ----------------- HTTP ROUTES ----------------- #

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/stream")
def sse_stream():
    """Server-Sent Events endpoint for real-time live event streaming to UI."""
    q = queue.Queue(maxsize=100)
    sse_subscribers.append(q)

    def event_stream():
        try:
            # Send initial ping
            yield "data: {\"type\": \"CONNECTION_ESTABLISHED\"}\n\n"
            while True:
                msg = q.get()
                yield msg
        except GeneratorExit:
            if q in sse_subscribers:
                sse_subscribers.remove(q)

    return Response(event_stream(), mimetype="text/event-stream")

@app.route("/api/events", methods=["GET"])
def get_events():
    limit = int(request.args.get("limit", 100))
    ftype = request.args.get("type", "ALL")
    frisk = request.args.get("risk", "ALL")
    events = telemetry_mgr.get_events(limit=limit, filter_type=ftype, filter_risk=frisk)
    return jsonify({"events": events, "count": len(events)})

@app.route("/api/metrics", methods=["GET"])
def get_metrics():
    metrics = telemetry_mgr.get_metrics()
    metrics["defense_mode"] = defense_orchestrator.mode
    metrics["blocked_ips_count"] = len(defense_orchestrator.get_blocked_ips())
    metrics["continuous_active"] = simulator.continuous_running
    return jsonify(metrics)

@app.route("/api/simulate/scenario", methods=["POST"])
def simulate_scenario():
    data = request.get_json() or {}
    scenario = data.get("scenario", "benign")
    count = int(data.get("count", 1))
    custom_ip = data.get("custom_ip")
    
    results = simulator.run_scenario(scenario, count=count, custom_ip=custom_ip)
    return jsonify({
        "success": True,
        "scenario": scenario,
        "executed_count": len(results),
        "results": results[:5]  # return first 5 sample results
    })

@app.route("/api/simulate/custom", methods=["POST"])
def simulate_custom():
    data = request.get_json() or {}
    ip = data.get("ip", "192.0.2.77")
    endpoint = data.get("endpoint", "/api/v1/search")
    method = data.get("method", "POST")
    payload = data.get("payload", "' OR 1=1 --")
    user = data.get("user", "custom_actor")
    session_id = data.get("session_id")

    res = simulator.inject_custom(
        ip=ip,
        endpoint=endpoint,
        method=method,
        payload=payload,
        user=user,
        session_id=session_id
    )
    return jsonify({"success": True, "event": res})

@app.route("/api/simulator/continuous", methods=["POST"])
def toggle_continuous_simulation():
    data = request.get_json() or {}
    enabled = bool(data.get("enabled", True))
    interval = float(data.get("interval", 1.8))
    
    if enabled:
        simulator.start_continuous(interval_seconds=interval)
    else:
        simulator.stop_continuous()
        
    return jsonify({"success": True, "continuous_active": simulator.continuous_running})

@app.route("/api/firewall", methods=["GET"])
def get_firewall():
    return jsonify({
        "blocked_ips": defense_orchestrator.get_blocked_ips(),
        "total_blocked": len(defense_orchestrator.get_blocked_ips())
    })

@app.route("/api/firewall/block", methods=["POST"])
def block_ip_manual():
    data = request.get_json() or {}
    ip = data.get("ip")
    reason = data.get("reason", "Manual security officer enforcement")
    if not ip:
        return jsonify({"error": "IP is required"}), 400
    res = defense_orchestrator.block_ip(ip, reason=reason, attack_type="MANUAL_ENFORCEMENT", risk_score=90, auto=False)
    return jsonify({"success": True, "rule": res})

@app.route("/api/firewall/unblock", methods=["POST"])
def unblock_ip():
    data = request.get_json() or {}
    ip = data.get("ip")
    if not ip:
        return jsonify({"error": "IP is required"}), 400
    success = defense_orchestrator.unblock_ip(ip)
    return jsonify({"success": success, "ip": ip})

@app.route("/api/sessions", methods=["GET"])
def get_sessions():
    return jsonify({"sessions": telemetry_mgr.get_sessions()})

@app.route("/api/sessions/terminate", methods=["POST"])
def terminate_session():
    data = request.get_json() or {}
    session_id = data.get("session_id")
    reason = data.get("reason", "Manual Operator Termination")
    if not session_id:
        return jsonify({"error": "session_id required"}), 400
    ok = telemetry_mgr.terminate_session(session_id, reason=reason)
    return jsonify({"success": ok, "session_id": session_id})

@app.route("/api/sessions/restore", methods=["POST"])
def restore_session():
    data = request.get_json() or {}
    session_id = data.get("session_id")
    if session_id in telemetry_mgr.sessions:
        telemetry_mgr.sessions[session_id]["status"] = "ACTIVE"
        return jsonify({"success": True, "session_id": session_id})
    return jsonify({"error": "Not found"}), 404

@app.route("/api/defense/mode", methods=["POST"])
def set_defense_mode():
    data = request.get_json() or {}
    mode = data.get("mode", "AUTONOMOUS").upper()
    ok = defense_orchestrator.set_mode(mode)
    return jsonify({"success": ok, "mode": defense_orchestrator.mode})

@app.route("/api/system/reset", methods=["POST"])
def system_reset():
    simulator.stop_continuous()
    telemetry_mgr.reset()
    defense_orchestrator.clear_firewall()
    seed_initial_state()
    return jsonify({"success": True, "message": "System state reset successfully"})

if __name__ == "__main__":
    print("=" * 65)
    print("AI-Driven Autonomous Cyber Defense and Intelligent Threat Response Simulator")
    print("Cybersecurity Operations Center listening on http://127.0.0.1:5000")
    print("=" * 65)
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
