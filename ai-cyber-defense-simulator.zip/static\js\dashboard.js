/**
 * AI-Driven Autonomous Cyber Defense and Intelligent Threat Response Simulator
 * Frontend Controller & Real-Time Security Operations Center (SOC) Engine
 */

let sseSource = null;
let trafficChart = null;
let categoryChart = null;
let audioEnabled = false;
let currentEventsCache = [];
let audioCtx = null;

// Initialize when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
    initCharts();
    initSSE();
    setupEventListeners();
    refreshAllData();
    // Poll metrics every 3 seconds as a heartbeat
    setInterval(fetchMetrics, 3000);
});

// ----------------- CHARTS SETUP ----------------- //

function initCharts() {
    const ctxTraffic = document.getElementById("trafficTimelineChart")?.getContext("2d");
    if (ctxTraffic) {
        trafficChart = new Chart(ctxTraffic, {
            type: "line",
            data: {
                labels: [],
                datasets: [
                    {
                        label: "Total Telemetry Volume",
                        borderColor: "#00f0ff",
                        backgroundColor: "rgba(0, 240, 255, 0.1)",
                        fill: true,
                        tension: 0.3,
                        data: [],
                        borderWidth: 2,
                        pointRadius: 2
                    },
                    {
                        label: "Threats Neutralized",
                        borderColor: "#ff2a5f",
                        backgroundColor: "rgba(255, 42, 95, 0.15)",
                        fill: true,
                        tension: 0.3,
                        data: [],
                        borderWidth: 2,
                        pointRadius: 3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: "#8492a6", font: { family: "Inter", size: 11 } } }
                },
                scales: {
                    x: { ticks: { color: "#8492a6", font: { family: "JetBrains Mono", size: 10 } }, grid: { color: "rgba(255,255,255,0.05)" } },
                    y: { ticks: { color: "#8492a6", font: { family: "JetBrains Mono", size: 10 }, stepSize: 1 }, grid: { color: "rgba(255,255,255,0.05)" }, beginAtZero: true }
                }
            }
        });
    }

    const ctxCat = document.getElementById("categoryDoughnutChart")?.getContext("2d");
    if (ctxCat) {
        categoryChart = new Chart(ctxCat, {
            type: "doughnut",
            data: {
                labels: ["Benign", "Brute Force", "SQLi", "XSS", "Traversal", "DDoS", "Recon"],
                datasets: [{
                    data: [1, 0, 0, 0, 0, 0, 0],
                    backgroundColor: [
                        "#00ff88",
                        "#ff2a5f",
                        "#ffb703",
                        "#9d4edd",
                        "#00b4d8",
                        "#e63946",
                        "#457b9d"
                    ],
                    borderColor: "#070b14",
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: "right", labels: { color: "#8492a6", font: { family: "Inter", size: 11 } } }
                },
                cutout: "68%"
            }
        });
    }
}

// ----------------- SERVER-SENT EVENTS (SSE) ----------------- //

function initSSE() {
    if (!!window.EventSource) {
        sseSource = new EventSource("/api/stream");
        sseSource.onmessage = (e) => {
            try {
                const data = JSON.parse(e.data);
                if (data.type === "CONNECTION_ESTABLISHED") return;
                handleIncomingEvent(data);
            } catch (err) {
                console.error("SSE parse error", err);
            }
        };
        sseSource.onerror = (err) => {
            console.warn("SSE disconnected, attempting reconnection in 4s...");
            sseSource.close();
            setTimeout(initSSE, 4000);
        };
    }
}

function handleIncomingEvent(event) {
    currentEventsCache.unshift(event);
    if (currentEventsCache.length > 500) currentEventsCache.pop();

    // Play cyber alert sound for Critical/High attacks if audio enabled
    if (audioEnabled && (event.risk_level === "CRITICAL" || event.risk_level === "HIGH")) {
        playCyberAlert();
    }

    // Prepend row to Live Event Stream Table
    renderEventRow(event, true);

    // Refresh metrics & charts
    fetchMetrics();

    // If Firewall or Sessions tab is active, refresh those too
    const activeTab = document.querySelector(".tab-btn.active")?.dataset.tab;
    if (activeTab === "firewall") fetchFirewall();
    if (activeTab === "sessions") fetchSessions();
}

// ----------------- AUDIO SYNTHESIZER ----------------- //

function playCyberAlert() {
    try {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(580, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(220, audioCtx.currentTime + 0.18);
        gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.18);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.18);
    } catch (e) {
        console.warn("Audio play prevented:", e);
    }
}

// ----------------- UI RENDERING ----------------- //

function renderEventRow(ev, isNew = false) {
    const tbody = document.getElementById("eventsTableBody");
    if (!tbody) return;

    // Check if table is showing empty placeholder
    const emptyRow = document.getElementById("emptyEventsRow");
    if (emptyRow) emptyRow.remove();

    const tr = document.createElement("tr");
    if (isNew) {
        tr.style.animation = "fadeInRow 0.4s ease";
    }

    // Determine risk class
    const rLevel = (ev.risk_level || "LOW").toUpperCase();
    const riskBadgeClass = `risk-${rLevel.toLowerCase()}`;

    // Actions badge summary
    let actionBadgesHtml = "";
    if (ev.actions_taken && ev.actions_taken.length > 0) {
        actionBadgesHtml = ev.actions_taken.map(a => {
            let actClass = "action-allow";
            if (a.action === "BLOCK_IP") actClass = "action-block";
            else if (a.action === "TERMINATE_SESSION") actClass = "action-term";
            else if (a.action === "SECURITY_ALERT") actClass = "action-alert";
            else if (a.action === "DROPPED") actClass = "action-dropped";
            return `<span class="action-badge ${actClass}">${escapeHtml(a.action)}</span>`;
        }).join(" ");
    } else {
        actionBadgesHtml = `<span class="action-badge action-allow">ALLOW</span>`;
    }

    tr.innerHTML = `
        <td style="font-family: var(--font-mono); color: var(--text-muted); font-size: 0.75rem;">${escapeHtml(ev.timestamp)}</td>
        <td>
            <div style="font-family: var(--font-mono); font-weight: 600; color: var(--accent-cyan); display: flex; align-items: center; gap: 4px;">
                <span>${escapeHtml(ev.ip)}</span>
            </div>
            <div style="font-size: 0.7rem; color: var(--text-muted); font-family: var(--font-mono);">${escapeHtml(ev.method)} ${escapeHtml(ev.endpoint)}</div>
        </td>
        <td>
            <span style="font-weight: 600; color: var(--text-bright);">${escapeHtml(ev.classification)}</span>
            <div style="font-size: 0.7rem; color: var(--text-muted); font-family: var(--font-mono);">${ev.confidence}% conf</div>
        </td>
        <td>
            <span class="risk-pill ${riskBadgeClass}">
                ${rLevel} (${ev.risk_score})
            </span>
        </td>
        <td>
            <div style="display: flex; flex-wrap: wrap; gap: 3px;">
                ${actionBadgesHtml}
            </div>
            <div style="font-size: 0.68rem; color: var(--text-muted); font-family: var(--font-mono); margin-top: 2px;">
                ⚡ ${ev.response_time_ms || 2.4}ms
            </div>
        </td>
        <td>
            <button class="btn btn-subtle" style="padding: 0.2rem 0.55rem; font-size: 0.72rem;" onclick="openIncidentModal('${ev.id}')">
                Inspect
            </button>
        </td>
    `;

    tbody.insertBefore(tr, tbody.firstChild);

    // Limit table DOM rows to 100 for performance
    if (tbody.children.length > 100) {
        tbody.removeChild(tbody.lastChild);
    }
}

// ----------------- DATA FETCHING ----------------- //

async function fetchMetrics() {
    try {
        const res = await fetch("/api/metrics");
        const m = await res.json();

        // Update top metric indicators
        document.getElementById("statTotalIngested").innerText = m.total_ingested.toLocaleString();
        document.getElementById("statThreatsNeutralized").innerText = m.threats_neutralized.toLocaleString();
        document.getElementById("statFirewallBans").innerText = m.blocked_ips_count;
        document.getElementById("statSessionsRevoked").innerText = m.sessions_terminated;

        // DEFCON badge
        const defconPill = document.getElementById("defconIndicator");
        if (defconPill) {
            defconPill.innerText = m.defcon;
            defconPill.style.color = m.defcon_color;
            defconPill.style.borderColor = m.defcon_color;
        }

        // Mode button state
        const modeBtn = document.getElementById("btnToggleMode");
        if (modeBtn) {
            if (m.defense_mode === "AUTONOMOUS") {
                modeBtn.className = "btn btn-mode-autonomous";
                modeBtn.innerHTML = `🛡️ Mode: Autonomous Active`;
            } else {
                modeBtn.className = "btn btn-mode-advisory";
                modeBtn.innerHTML = `⚠️ Mode: Advisory Only`;
            }
        }

        // Continuous traffic toggle button state
        const contBtn = document.getElementById("btnToggleContinuous");
        if (contBtn) {
            if (m.continuous_active) {
                contBtn.className = "btn btn-danger";
                contBtn.innerHTML = `<span class="pulse-dot"></span> Bot Traffic: ON`;
            } else {
                contBtn.className = "btn btn-subtle";
                contBtn.innerHTML = `🤖 Bot Traffic: OFF`;
            }
        }

        // Update Charts
        updateCharts(m);

    } catch (err) {
        console.error("fetchMetrics error:", err);
    }
}

function updateCharts(m) {
    if (trafficChart && m.timeline) {
        const labels = m.timeline.map(t => t.time);
        const totals = m.timeline.map(t => t.total);
        const threats = m.timeline.map(t => t.threats);
        trafficChart.data.labels = labels;
        trafficChart.data.datasets[0].data = totals;
        trafficChart.data.datasets[1].data = threats;
        trafficChart.update("none");
    }

    if (categoryChart && m.category_counts) {
        const cats = m.category_counts;
        categoryChart.data.datasets[0].data = [
            cats.BENIGN || 0,
            cats.BRUTE_FORCE || 0,
            cats.SQL_INJECTION || 0,
            cats.XSS || 0,
            cats.PATH_TRAVERSAL || 0,
            cats.DDOS_FLOOD || 0,
            cats.RECON_SCAN || 0
        ];
        categoryChart.update("none");
    }
}

async function fetchEventsInitial() {
    try {
        const res = await fetch("/api/events?limit=40");
        const data = await res.json();
        currentEventsCache = data.events || [];
        const tbody = document.getElementById("eventsTableBody");
        if (tbody) tbody.innerHTML = "";
        currentEventsCache.forEach(ev => renderEventRow(ev, false));
    } catch (err) {
        console.error("fetchEventsInitial error:", err);
    }
}

async function fetchFirewall() {
    try {
        const res = await fetch("/api/firewall");
        const data = await res.json();
        const tbody = document.getElementById("firewallTableBody");
        if (!tbody) return;

        if (data.blocked_ips.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 1.5rem;">No active IP bans currently enforced. Perimeter is clear.</td></tr>`;
            return;
        }

        tbody.innerHTML = data.blocked_ips.map(rule => `
            <tr>
                <td style="font-family: var(--font-mono); font-weight: 700; color: var(--accent-red);">${escapeHtml(rule.ip)}</td>
                <td style="font-family: var(--font-mono); font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(rule.blocked_at)}</td>
                <td><span class="tag-badge tag-red">${escapeHtml(rule.attack_type)}</span></td>
                <td style="font-size: 0.78rem; color: var(--text-main);">${escapeHtml(rule.reason)}</td>
                <td>
                    <button class="btn btn-subtle" style="padding: 0.2rem 0.5rem; font-size: 0.72rem; color: var(--accent-green);" onclick="unblockIp('${rule.ip}')">
                        Release Ban
                    </button>
                </td>
            </tr>
        `).join("");
    } catch (err) {
        console.error("fetchFirewall error:", err);
    }
}

async function fetchSessions() {
    try {
        const res = await fetch("/api/sessions");
        const data = await res.json();
        const tbody = document.getElementById("sessionsTableBody");
        if (!tbody) return;

        tbody.innerHTML = data.sessions.map(s => {
            const isActive = s.status === "ACTIVE";
            const statusBadge = isActive 
                ? `<span class="tag-badge tag-green">ACTIVE</span>` 
                : `<span class="tag-badge tag-red">TERMINATED</span>`;

            const actionBtn = isActive
                ? `<button class="btn btn-danger" style="padding: 0.2rem 0.5rem; font-size: 0.72rem;" onclick="terminateSession('${s.session_id}')">Revoke</button>`
                : `<button class="btn btn-subtle" style="padding: 0.2rem 0.5rem; font-size: 0.72rem; color: var(--accent-cyan);" onclick="restoreSession('${s.session_id}')">Restore</button>`;

            return `
                <tr>
                    <td style="font-family: var(--font-mono); color: var(--accent-cyan); font-weight: 600;">${escapeHtml(s.session_id)}</td>
                    <td style="font-weight: 600;">${escapeHtml(s.user)}</td>
                    <td style="font-family: var(--font-mono); font-size: 0.75rem;">${escapeHtml(s.ip)}</td>
                    <td>${statusBadge}</td>
                    <td style="font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(s.revoke_reason || "Normal Session")}</td>
                    <td>${actionBtn}</td>
                </tr>
            `;
        }).join("");
    } catch (err) {
        console.error("fetchSessions error:", err);
    }
}

function refreshAllData() {
    fetchMetrics();
    fetchEventsInitial();
    fetchFirewall();
    fetchSessions();
}

// ----------------- USER ACTIONS ----------------- //

async function triggerScenario(scenarioName, count = 1) {
    try {
        const btn = document.querySelector(`[data-scenario="${scenarioName}"]`);
        if (btn) btn.style.opacity = "0.5";

        const res = await fetch("/api/simulate/scenario", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ scenario: scenarioName, count: count })
        });
        const data = await res.json();
        if (btn) btn.style.opacity = "1";
    } catch (err) {
        console.error("triggerScenario error:", err);
    }
}

async function injectCustomThreat() {
    const ip = document.getElementById("customIp")?.value;
    const endpoint = document.getElementById("customEndpoint")?.value;
    const method = document.getElementById("customMethod")?.value;
    const payload = document.getElementById("customPayload")?.value;
    const session_id = document.getElementById("customSession")?.value;

    try {
        const res = await fetch("/api/simulate/custom", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ip, endpoint, method, payload, session_id })
        });
        const data = await res.json();
    } catch (err) {
        console.error("injectCustomThreat error:", err);
    }
}

async function toggleAutonomousMode() {
    try {
        const modeBtn = document.getElementById("btnToggleMode");
        const currentMode = modeBtn?.innerText.includes("Autonomous") ? "AUTONOMOUS" : "ADVISORY";
        const newMode = currentMode === "AUTONOMOUS" ? "ADVISORY" : "AUTONOMOUS";

        await fetch("/api/defense/mode", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ mode: newMode })
        });
        fetchMetrics();
    } catch (err) {
        console.error("toggleAutonomousMode error:", err);
    }
}

async function toggleContinuousTraffic() {
    try {
        const contBtn = document.getElementById("btnToggleContinuous");
        const isRunning = contBtn?.innerText.includes("ON");
        
        await fetch("/api/simulator/continuous", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ enabled: !isRunning, interval: 1.6 })
        });
        fetchMetrics();
    } catch (err) {
        console.error("toggleContinuousTraffic error:", err);
    }
}

async function unblockIp(ip) {
    try {
        await fetch("/api/firewall/unblock", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ip: ip })
        });
        fetchFirewall();
        fetchMetrics();
    } catch (err) {
        console.error("unblockIp error:", err);
    }
}

async function manualBlockIp() {
    const ip = document.getElementById("manualBlockIp")?.value;
    const reason = document.getElementById("manualBlockReason")?.value;
    if (!ip) return alert("Please enter a valid IP address");

    try {
        await fetch("/api/firewall/block", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ip: ip, reason: reason })
        });
        document.getElementById("manualBlockIp").value = "";
        fetchFirewall();
        fetchMetrics();
    } catch (err) {
        console.error("manualBlockIp error:", err);
    }
}

async function terminateSession(sessionId) {
    try {
        await fetch("/api/sessions/terminate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ session_id: sessionId })
        });
        fetchSessions();
        fetchMetrics();
    } catch (err) {
        console.error("terminateSession error:", err);
    }
}

async function restoreSession(sessionId) {
    try {
        await fetch("/api/sessions/restore", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ session_id: sessionId })
        });
        fetchSessions();
        fetchMetrics();
    } catch (err) {
        console.error("restoreSession error:", err);
    }
}

async function resetSystem() {
    if (!confirm("Reset all telemetry, active firewall bans, and session registries?")) return;
    try {
        await fetch("/api/system/reset", { method: "POST" });
        refreshAllData();
    } catch (err) {
        console.error("resetSystem error:", err);
    }
}

// ----------------- MODAL INSPECTOR ----------------- //

function openIncidentModal(eventId) {
    const ev = currentEventsCache.find(e => e.id === eventId);
    if (!ev) return;

    const modal = document.getElementById("incidentModal");
    const container = document.getElementById("modalDetailsContainer");
    if (!modal || !container) return;

    const rLevel = (ev.risk_level || "LOW").toUpperCase();
    const riskBadgeClass = `risk-${rLevel.toLowerCase()}`;

    let reasonsHtml = (ev.reasons || []).map(r => `<li>${escapeHtml(r)}</li>`).join("");
    if (!reasonsHtml) reasonsHtml = "<li>Behavior aligns within expected baseline bounds.</li>";

    let actionsHtml = (ev.actions_taken || []).map(a => `
        <div style="background: rgba(13, 21, 39, 0.6); border-left: 3px solid var(--accent-cyan); padding: 0.5rem 0.8rem; margin-bottom: 0.4rem; border-radius: 4px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <span class="action-badge action-block">${escapeHtml(a.action)}</span>
                <span style="font-family: var(--font-mono); font-size: 0.7rem; color: var(--accent-green);">${escapeHtml(a.status || 'ENFORCED')}</span>
            </div>
            <div style="font-size: 0.78rem; color: var(--text-main); margin-top: 0.25rem;">${escapeHtml(a.description || '')}</div>
        </div>
    `).join("");

    const feats = ev.features || {};

    container.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <div>
                <span style="font-size: 0.72rem; color: var(--text-muted); font-family: var(--font-mono);">INCIDENT REF: #${escapeHtml(ev.id)}</span>
                <h3 style="color: var(--text-bright); font-size: 1.25rem; font-weight: 700;">${escapeHtml(ev.classification)}</h3>
            </div>
            <div style="text-align: right;">
                <span class="risk-pill ${riskBadgeClass}" style="font-size: 0.85rem; padding: 0.3rem 0.8rem;">
                    RISK SCORE: ${ev.risk_score} / 100 [${rLevel}]
                </span>
                <div style="font-size: 0.75rem; color: var(--text-muted); font-family: var(--font-mono); margin-top: 4px;">
                    Algorithm Confidence: ${ev.confidence}%
                </div>
            </div>
        </div>

        <!-- MITRE ATT&CK Banner -->
        <div style="background: rgba(0, 240, 255, 0.08); border: 1px solid rgba(0, 240, 255, 0.25); border-radius: 6px; padding: 0.65rem 0.9rem; margin-bottom: 1rem; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <span style="font-size: 0.7rem; color: var(--accent-cyan); font-family: var(--font-mono); font-weight: 700;">MITRE ATT&CK FRAMEWORK</span>
                <div style="font-size: 0.85rem; font-weight: 600; color: var(--text-bright);">${escapeHtml(ev.mitre?.id || 'N/A')} - ${escapeHtml(ev.mitre?.name || 'Standard Network Traffic')}</div>
            </div>
            <span class="tag-badge tag-blue">${escapeHtml(ev.mitre?.tactic || 'General')}</span>
        </div>

        <!-- Feature telemetry grid -->
        <div class="feature-grid">
            <div class="feature-box">
                <div class="label">Shannon Entropy</div>
                <div class="val">${feats.entropy ?? 'N/A'}</div>
            </div>
            <div class="feature-box">
                <div class="label">Special Char Density</div>
                <div class="val">${feats.special_ratio ? (feats.special_ratio * 100).toFixed(1) + '%' : '0%'}</div>
            </div>
            <div class="feature-box">
                <div class="label">Velocity (Req/10s)</div>
                <div class="val">${feats.req_rate_10s ?? '1.0'}</div>
            </div>
            <div class="feature-box">
                <div class="label">Auth Failures (30s)</div>
                <div class="val">${feats.failed_logins_30s ?? '0'}</div>
            </div>
            <div class="feature-box">
                <div class="label">Anomaly Metric</div>
                <div class="val">${ev.anomaly_score ?? '0.0'}</div>
            </div>
            <div class="feature-box">
                <div class="label">Latency to Mitigate</div>
                <div class="val" style="color: var(--accent-green);">${ev.response_time_ms || 2.4} ms</div>
            </div>
        </div>

        <!-- Explainable AI (XAI) Reasons -->
        <div style="margin: 1rem 0;">
            <h4 style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; font-family: var(--font-mono); margin-bottom: 0.5rem;">
                🧠 Explainable AI Decision Evidence
            </h4>
            <ul style="padding-left: 1.2rem; font-size: 0.82rem; color: var(--text-main); line-height: 1.6;">
                ${reasonsHtml}
            </ul>
        </div>

        <!-- Raw Payload -->
        <div style="margin: 1rem 0;">
            <h4 style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; font-family: var(--font-mono); margin-bottom: 0.5rem;">
                📦 Ingested Request Payload & Endpoint
            </h4>
            <div style="font-family: var(--font-mono); font-size: 0.75rem; color: var(--text-muted); margin-bottom: 0.3rem;">
                <strong>${escapeHtml(ev.method)}</strong> ${escapeHtml(ev.endpoint)} from <strong>${escapeHtml(ev.ip)}</strong>
            </div>
            <div class="payload-box">${escapeHtml(ev.payload || '(Empty payload body)')}</div>
        </div>

        <!-- Autonomous SOAR Actions Orchestrated -->
        <div style="margin-top: 1rem;">
            <h4 style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; font-family: var(--font-mono); margin-bottom: 0.5rem;">
                ⚡ Autonomous SOAR Containment Actions
            </h4>
            <div>${actionsHtml}</div>
        </div>
    `;

    modal.classList.add("open");
}

function closeIncidentModal() {
    const modal = document.getElementById("incidentModal");
    if (modal) modal.classList.remove("open");
}

// ----------------- EVENT LISTENERS & TABS ----------------- //

function setupEventListeners() {
    // Tab switching
    document.querySelectorAll(".tab-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");

            const tabName = btn.dataset.tab;
            document.querySelectorAll(".tab-pane").forEach(pane => {
                pane.style.display = pane.id === `tab-${tabName}` ? "block" : "none";
            });

            if (tabName === "firewall") fetchFirewall();
            if (tabName === "sessions") fetchSessions();
        });
    });

    // Audio toggle
    document.getElementById("btnToggleAudio")?.addEventListener("click", function() {
        audioEnabled = !audioEnabled;
        this.innerHTML = audioEnabled ? "🔊 Audio: ON" : "🔇 Audio: OFF";
        if (audioEnabled) {
            this.classList.add("btn-primary");
            this.classList.remove("btn-subtle");
            playCyberAlert();
        } else {
            this.classList.remove("btn-primary");
            this.classList.add("btn-subtle");
        }
    });

    // Close modal on escape
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") closeIncidentModal();
    });
}

function escapeHtml(str) {
    if (!str) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
